package utils;

import models.Cliente;
import models.Pedido;
import models.Producto;
import models.Trabajador;

import java.util.ArrayList;

public class Email {
    public static String mensajeConfirmaPedido(Cliente cliente, Pedido pedido){
        StringBuilder productosHtml = new StringBuilder();
        double precioTotal = 0.0;

        for (Producto producto : pedido.getProductos()) {
            productosHtml.append("<tr>")
                    .append("<td style='border: 1px solid #ddd; padding: 8px;'>").append(producto.getMarca()).append("</td>")
                    .append("<td style='border: 1px solid #ddd; padding: 8px;'>").append(producto.getModelo()).append("</td>")
                    .append("<td style='border: 1px solid #ddd; padding: 8px;'>").append(String.format("%.2f", producto.getPrecio())).append("E</td>")
                    .append("</tr>");
            precioTotal += producto.getPrecio();
        }

        String htmlcode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Confirmación de Pedido</title>\n" +
                "    <style>\n" +
                "        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }\n" +
                "        .container { max-width: 80%; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); margin-top: 20px; }\n" +
                "        .header { text-align: center; background: #031a45; padding: 20px; color: white; border-radius: 8px 8px 0 0; }\n" +
                "        .content { padding: 20px; font-size: 16px; line-height: 1.6; color: #333; }\n" +
                "        table { width: 100%; border-collapse: collapse; margin-top: 20px; }\n" +
                "        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n" +
                "        th { background-color: #031a45; color: white; }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Confirmación de Pedido</h1>\n" +
                "        </div>\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a <strong>"+ cliente.getNombre() +"</strong>, su pedido ha sido confirmado.</p>\n" +
                "            <p><strong>ID del Pedido:</strong> "+ pedido.getId() +"</p>\n" +
                "            <p><strong>Fecha del Pedido:</strong> "+ Utils.formatearFecha(pedido.getFechaPedido()) +"</p>\n" +
                "            <p><strong>Fecha Estimada de Entrega:</strong> "+ Utils.formatearFecha(pedido.getFechaEstimada()) +"</p>\n" +
                "            <table>\n" +
                "                <tr>\n" +
                "                    <th>Marca</th>\n" +
                "                    <th>Modelo</th>\n" +
                "                    <th>Precio (E)</th>\n" +
                "                </tr>\n" +
                "                "+ productosHtml.toString() +"\n" +
                "            </table>\n" +
                "            <p><strong>Precio Total:</strong> "+ String.format("%.2f", precioTotal) +"E</p>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";

        return htmlcode;
    }

    public static String mensajeRegistroCliente(String nombre, String codigoVerificacion){
        String htmlCode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Confirmación de suscripción</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: Arial, sans-serif;\n" +
                "            background-color: #f4f4f4;\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "            color: black;\n" +
                "        }\n" +
                "        .container {\n" +
                "            width: 100%;\n" +
                "            color: black;\n" +
                "            max-width: 80%;\n" +
                "            margin: 0 auto;\n" +
                "            background-color: #ffffff;\n" +
                "            padding: 20px;\n" +
                "            border-radius: 8px;\n" +
                "            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .header {\n" +
                "            text-align: center;\n" +
                "            background-color: #031a45;\n" +
                "            padding: 20px;\n" +
                "            color: white;\n" +
                "            border-radius: 8px 8px 0 0;\n" +
                "        }\n" +
                "        .header h1 {\n" +
                "            margin: 0;\n" +
                "        }\n" +
                "        .content {\n" +
                "            padding: 20px;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.6;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .button {\n" +
                "            display: inline-block;\n" +
                "            background: radial-gradient(circle, rgba(6,86,172,0.6465968586387434) 0%, rgb(5, 28, 74) 100%, rgba(9,9,121,1) 100%, rgba(2,0,36,1) 100%);\n" +
                "            color: rgb(255, 255, 255);\n" +
                "            padding: 15px 25px;\n" +
                "            font-size: 25px;\n" +
                "            font-weight: bold;\n" +
                "            text-decoration: none;\n" +
                "            border-radius: 5px;\n" +
                "            margin-top: 20px;\n" +
                "            min-width: 20%;\n" +
                "        }\n" +
                "        .footer {\n" +
                "            text-align: center;\n" +
                "            font-size: 12px;\n" +
                "            color: #777;\n" +
                "        }\n" +
                "        .footer a {\n" +
                "            color: rgba(5, 77, 153, 0.716);\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "        }\n" +
                "        #cajaBoton {\n" +
                "            width: 100%;\n" +
                "            text-align: center;\n" +
                "        }\n" +
                "        #creditos {\n" +
                "            line-height: 10px;\n" +
                "            margin: 20px;\n" +
                "            margin-top: 50px;\n" +
                "            padding: 5px;\n" +
                "            background-color: rgba(0, 14, 54, 0.932);\n" +
                "            border-radius: 0 0 8px 8px;\n" +
                "            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "        }\n" +
                "        #derechos {\n" +
                "            margin-bottom: 40px;\n" +
                "        }\n" +
                "        .footer div p a {\n" +
                "            text-decoration: none;\n" +
                "            color: rgba(190, 207, 252, 0.948);\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <!-- Header -->\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Confirmación de Suscripción</h1>\n" +
                "        </div>\n" +
                "        <!-- Content -->\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a <strong>"+ nombre +"</strong>,</p>\n" +
                "            <p>¡Gracias por confiar en nosotros! Este es un correo de validación para confirmar su email.</p>\n" +
                "            <p>Si no se ha registrado en esta página, por favor, considere cambiar la contraseña de su correo e ignorar este email, puede haber sido robado.</p>\n" +
                "            <p>Su código de validación de email es el siguiente:</p>\n" +
                "            <div id=\"cajaBoton\">\n" +
                "                <p href=\"http://enlace-de-validacion.com/\" class=\"button\" id=\"botonCodigo\">" + codigoVerificacion + "</p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "        <!-- Footer -->\n" +
                "        <div class=\"footer\">\n" +
                "            <p>Si tienes alguna duda, no dudes en contactarnos.</p>\n" +
                "            <p>Contáctanos en: <a href=\"mailto:fernanshopmz@gmail.com\">fernanshopmz@gmail.com</a></p>\n" +
                "            <p>Síguenos en nuestras redes sociales:</p>\n" +
                "            <p>\n" +
                "                <a href=\"http://facebook.com\">Facebook</a> | \n" +
                "                <a href=\"http://instagram.com\">Instagram</a>\n" +
                "            </p>\n" +
                "            <p id=\"derechos\">&copy; 2025 FernanShopMZ. Todos los derechos reservados.</p>\n" +
                "            <div id=\"creditos\">\n" +
                "                <h3>Práctica Realizada por:</h3>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1fG-SZVLy7ro9E0eHXN7-obQcf9v1ETBY/view?usp=drive_link\">Mireya Cueto Garrido</a></p>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1DgSO2qZMh6u2PS6zVmm_C7uw6MzhAYvz/view?usp=drive_link\">Zamira Suriel Matías</a></p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
        return htmlCode;
    }

    public static String mensajeBienvenidaTrabajador(String nombre){
        String htmlCode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Confirmación de suscripción</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: Arial, sans-serif;\n" +
                "            background-color: #f4f4f4;\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "            color: black;\n" +
                "        }\n" +
                "        .container {\n" +
                "            width: 100%;\n" +
                "            color: black;\n" +
                "            max-width: 80%;\n" +
                "            margin: 0 auto;\n" +
                "            background-color: #ffffff;\n" +
                "            padding: 20px;\n" +
                "            border-radius: 8px;\n" +
                "            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .header {\n" +
                "            text-align: center;\n" +
                "            background-color: #be5b09;\n" +
                "            padding: 20px;\n" +
                "            color: white;\n" +
                "            border-radius: 8px 8px 0 0;\n" +
                "        }\n" +
                "        .header h1 {\n" +
                "            margin: 0;\n" +
                "        }\n" +
                "        .content {\n" +
                "            padding: 20px;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.6;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .footer {\n" +
                "            text-align: center;\n" +
                "            font-size: 12px;\n" +
                "            color: #777;\n" +
                "        }\n" +
                "        .footer a {\n" +
                "            color: #be5b09;\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "        }\n" +
                "        #creditos {\n" +
                "            line-height: 10px;\n" +
                "            margin: 20px;\n" +
                "            margin-top: 50px;\n" +
                "            padding: 5px;\n" +
                "            background-color: #472203;\n" +
                "            border-radius: 0 0 8px 8px;\n" +
                "            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "        }\n" +
                "        #derechos {\n" +
                "            margin-bottom: 40px;\n" +
                "        }\n" +
                "        .footer div p a {\n" +
                "            text-decoration: none;\n" +
                "            color: #f1cdb0;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <!-- Header -->\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Bienvenid@ a FernanShopMZ</h1>\n" +
                "        </div>\n" +
                "        <!-- Content -->\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a trabajador/a <strong>"+nombre+"</strong>,</p>\n" +
                "            <p>¡Bienvenido a FernanShopMZ! Muchas gracias por completar el registro, ya eres parte de la familia.</p>\n" +
                "        </div>\n" +
                "        <!-- Footer -->\n" +
                "        <div class=\"footer\">\n" +
                "            <p>Para cualquier incidencia contacta a: <a href=\"mailto:fernanshopmz@gmail.com\">fernanshopmz@gmail.com</a></p>\n" +
                "            <p>Síguenos en nuestras redes sociales:</p>\n" +
                "            <p>\n" +
                "                <a href=\"http://facebook.com\">Facebook</a> | \n" +
                "                <a href=\"http://instagram.com\">Instagram</a>\n" +
                "            </p>\n" +
                "            <p id=\"derechos\">&copy; 2025 FernanShopMZ. Todos los derechos reservados.</p>\n" +
                "            <div id=\"creditos\">\n" +
                "                <h3>Práctica Realizada por:</h3>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1fG-SZVLy7ro9E0eHXN7-obQcf9v1ETBY/view?usp=drive_link\">Mireya Cueto Garrido</a></p>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1DgSO2qZMh6u2PS6zVmm_C7uw6MzhAYvz/view?usp=drive_link\">Zamira Suriel Matías</a></p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
        return htmlCode;
    }

    public static String mensajeDespedidaTrabajador(String nombre){
        String htmlCode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Confirmación de suscripción</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: Arial, sans-serif;\n" +
                "            background-color: #f4f4f4;\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "            color: black;\n" +
                "        }\n" +
                "        .container {\n" +
                "            width: 100%;\n" +
                "            color: black;\n" +
                "            max-width: 80%;\n" +
                "            margin: 0 auto;\n" +
                "            background-color: #ffffff;\n" +
                "            padding: 20px;\n" +
                "            border-radius: 8px;\n" +
                "            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .header {\n" +
                "            text-align: center;\n" +
                "            background-color: #be5b09;\n" +
                "            padding: 20px;\n" +
                "            color: white;\n" +
                "            border-radius: 8px 8px 0 0;\n" +
                "        }\n" +
                "        .header h1 {\n" +
                "            margin: 0;\n" +
                "        }\n" +
                "        .content {\n" +
                "            padding: 20px;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.6;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .footer {\n" +
                "            text-align: center;\n" +
                "            font-size: 12px;\n" +
                "            color: #777;\n" +
                "        }\n" +
                "        .footer a {\n" +
                "            color: #be5b09;\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "        }\n" +
                "        #creditos {\n" +
                "            line-height: 10px;\n" +
                "            margin: 20px;\n" +
                "            margin-top: 50px;\n" +
                "            padding: 5px;\n" +
                "            background-color: #472203;\n" +
                "            border-radius: 0 0 8px 8px;\n" +
                "            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "        }\n" +
                "        #derechos {\n" +
                "            margin-bottom: 40px;\n" +
                "        }\n" +
                "        .footer div p a {\n" +
                "            text-decoration: none;\n" +
                "            color: #f1cdb0;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <!-- Header -->\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Desde FernaShopMZ lo sentimos :(</h1>\n" +
                "        </div>\n" +
                "        <!-- Content -->\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a trabajador/a <strong>"+nombre+"</strong>,</p>\n" +
                "            <p>Has sido dado de baja de nuestra plantilla. Muchas gracias por haber formador parte de nuestra familia.</p>\n" +
                "            <p>No dudes en contactar con nosotros si desea volver a colaborar juntos.</p>\n" +
                "            <p>    - El Equipo FernanShopMZ <3</p>\n" +
                "        </div>\n" +
                "        <!-- Footer -->\n" +
                "        <div class=\"footer\">\n" +
                "            <p>Para cualquier incidencia contacta a: <a href=\"mailto:fernanshopmz@gmail.com\">fernanshopmz@gmail.com</a></p>\n" +
                "            <p>Síguenos en nuestras redes sociales:</p>\n" +
                "            <p>\n" +
                "                <a href=\"http://facebook.com\">Facebook</a> | \n" +
                "                <a href=\"http://instagram.com\">Instagram</a>\n" +
                "            </p>\n" +
                "            <p id=\"derechos\">&copy; 2025 FernanShopMZ. Todos los derechos reservados.</p>\n" +
                "            <div id=\"creditos\">\n" +
                "                <h3>Práctica Realizada por:</h3>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1fG-SZVLy7ro9E0eHXN7-obQcf9v1ETBY/view?usp=drive_link\">Mireya Cueto Garrido</a></p>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1DgSO2qZMh6u2PS6zVmm_C7uw6MzhAYvz/view?usp=drive_link\">Zamira Suriel Matías</a></p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
        return htmlCode;
    }

    public static String mensajeNuevoPedidoTrabajador(Trabajador trabajador, Pedido pedido, Cliente cliente){ //TODO: CAMBIAR EL EMAIL PARA MOSTRAR DATOS DEL PEDIDO
        String htmlCode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Nuevo Pedido Trabajador</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: Arial, sans-serif;\n" +
                "            background-color: #f4f4f4;\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "        }\n" +
                "        .container {\n" +
                "            width: 100%;\n" +
                "            max-width: 80%;\n" +
                "            margin: 0 auto;\n" +
                "            background-color: #ffffff;\n" +
                "            padding: 20px;\n" +
                "            border-radius: 8px;\n" +
                "            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .header {\n" +
                "            text-align: center;\n" +
                "            background-color: #be5b09;\n" +
                "            padding: 20px;\n" +
                "            color: white;\n" +
                "            border-radius: 8px 8px 0 0;\n" +
                "        }\n" +
                "        .content {\n" +
                "            padding: 20px;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.6;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .button {\n" +
                "            display: inline-block;\n" +
                "            background: radial-gradient(circle, rgba(172, 72, 6, 0.646) 0%, rgb(74, 35, 5) 100%);\n" +
                "            color: white;\n" +
                "            padding: 15px 25px;\n" +
                "            font-size: 25px;\n" +
                "            font-weight: bold;\n" +
                "            text-decoration: none;\n" +
                "            border-radius: 5px;\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .footer {\n" +
                "            text-align: center;\n" +
                "            font-size: 12px;\n" +
                "            color: #777;\n" +
                "        }\n" +
                "        .footer a {\n" +
                "            color: #be5b09;\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "        }\n" +
                "        #creditos {\n" +
                "            line-height: 10px;\n" +
                "            margin: 20px;\n" +
                "            margin-top: 50px;\n" +
                "            padding: 5px;\n" +
                "            background-color: #472203;\n" +
                "            border-radius: 0 0 8px 8px;\n" +
                "            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "        }\n" +
                "        .footer div p a {\n" +
                "            text-decoration: none;\n" +
                "            color: #f1cdb0;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Información del Pedido</h1>\n" +
                "        </div>\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a <strong>" + trabajador.getNombre() + "</strong>, con id <strong>"+ trabajador.getId() +"</strong>.</p>\n" +
                "            <div>\n" +
                "                <p>Estado: <strong>" + pedido.pintaEstado(pedido.getEstado()) + "</strong></p>\n" +
                "                <p>Cliente: <strong>" + cliente.getNombre() + " " + cliente.getNombre() + "</strong></p>\n" +
                "                <p>Dirección: <strong>" + cliente.getDireccion() + "</strong></p>\n" +
                "                <p>Localidad: <strong>" + cliente.getLocalidad() + "</strong></p>\n" +
                "                <p>Provincia: <strong>" + cliente.getProvincia() + "</strong></p>\n" +
                "                <p>Teléfono: <strong>" + cliente.getMovil() + "</strong></p>\n" +
                "                <p>Correo: <strong>" + cliente.getEmail() + "</strong></p>\n" +
                "                <p>Fecha pedido: <strong>" + pedido.getFechaPedido() + "</strong></p>\n" +
                "                <p>Entrega estimada: <strong>" + pedido.getFechaEstimada() + "</strong></p>\n" +
                "                <p>Comentarios: <strong>" + pedido.getComentario() + "</strong></p>\n" +
                "                <p class=\"button\">" + pedido.getId() + "</p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "        <div class=\"footer\">\n" +
                "            <p>Le deseamos un buen día lleno de arduo trabajo :)</p>\n" +
                "            <p>Email de empresa: <a href=\"mailto:fernanshopmz@gmail.com\">fernanshopmz@gmail.com</a></p>\n" +
                "            <p>Redes sociales:</p>\n" +
                "            <p>\n" +
                "                <a href=\"http://facebook.com\">Facebook</a> |\n" +
                "                <a href=\"http://instagram.com\">Instagram</a>\n" +
                "            </p>\n" +
                "            <p>&copy; 2025 FernanShopMZ. Todos los derechos reservados.</p>\n" +
                "            <div id=\"creditos\">\n" +
                "                <h3>Práctica Realizada por:</h3>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1fG-SZVLy7ro9E0eHXN7-obQcf9v1ETBY/view?usp=drive_link\">Mireya Cueto Garrido</a></p>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1DgSO2qZMh6u2PS6zVmm_C7uw6MzhAYvz/view?usp=drive_link\">Zamira Suriel Matías</a></p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
        return htmlCode;
    }

    public static String mensajeCambiaEstadoPedido(Cliente cliente, Pedido pedido){
        String htmlcode = "<!DOCTYPE html>\n" +
                "<html lang=\"es\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Estado de su pedido</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: Arial, sans-serif;\n" +
                "            background-color: #f4f4f4;\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "        }\n" +
                "        .container {\n" +
                "            width: 100%;\n" +
                "            max-width: 80%;\n" +
                "            margin: 0 auto;\n" +
                "            background-color: #ffffff;\n" +
                "            padding: 20px;\n" +
                "            border-radius: 8px;\n" +
                "            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .header {\n" +
                "            text-align: center;\n" +
                "            background-color: #031a45;\n" +
                "            padding: 20px;\n" +
                "            color: white;\n" +
                "            border-radius: 8px 8px 0 0;\n" +
                "        }\n" +
                "        .header h1 {\n" +
                "            margin: 0;\n" +
                "        }\n" +
                "        .content {\n" +
                "            padding: 20px;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.6;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .button {\n" +
                "            display: inline-block;\n" +
                "            background: radial-gradient(circle, rgba(6, 86, 172, 0.646) 0%, rgb(5, 28, 74) 100%);\n" +
                "            color: rgb(255, 255, 255);\n" +
                "            padding: 15px 25px;\n" +
                "            font-size: 25px;\n" +
                "            font-weight: bold;\n" +
                "            text-decoration: none;\n" +
                "            border-radius: 5px;\n" +
                "            margin-top: 20px;\n" +
                "        }\n" +
                "        .footer {\n" +
                "            text-align: center;\n" +
                "            font-size: 12px;\n" +
                "            color: #777;\n" +
                "        }\n" +
                "        .footer a {\n" +
                "            color: rgba(5, 77, 153, 0.716);\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "        }\n" +
                "        #cajaBoton {\n" +
                "            width: 100%;\n" +
                "            text-align: center;\n" +
                "        }\n" +
                "        #creditos {\n" +
                "            line-height: 10px;\n" +
                "            margin: 20px;\n" +
                "            margin-top: 50px;\n" +
                "            padding: 5px;\n" +
                "            background-color: rgba(0, 14, 54, 0.932);\n" +
                "            border-radius: 0 0 8px 8px;\n" +
                "            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "        }\n" +
                "        #derechos {\n" +
                "            margin-bottom: 40px;\n" +
                "        }\n" +
                "        .footer div p a {\n" +
                "            text-decoration: none;\n" +
                "            color: rgba(190, 207, 252, 0.948);\n" +
                "        }\n" +
                "        #infoPedido {\n" +
                "            margin: 0px 30px 0px 30px;\n" +
                "            padding: 10px;\n" +
                "            text-align: center;\n" +
                "            background-color: #031a45;\n" +
                "            color: rgb(224, 230, 245);\n" +
                "            border-radius: 15px;\n" +
                "            box-shadow: 0px 0px 15px #031a453a;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <div class=\"header\">\n" +
                "            <h1>Estado de su pedido actualizado</h1>\n" +
                "        </div>\n" +
                "        <div class=\"content\">\n" +
                "            <p>Estimado/a <strong>"+ cliente.getNombre() +"</strong>.</p>\n" +
                "            <p>El Estado de su Pedido con ID: <strong>"+ pedido.getId() +"</strong> ha sido cambiado a <strong>"+
                pedido.pintaEstado(pedido.getEstado()) +"</strong>.</p>\n" +
                "            <p>A continuación, se le muestra la información del pedido:</p>\n" +
                "            <div id=\"infoPedido\">\n" +
                "                <p><strong>Estado: </strong>"+ pedido.pintaEstado(pedido.getEstado()) +"</p>\n" +
                "                <p><strong>Usuario: </strong>"+ cliente.getNombre() +"</p>\n" +
                "                <p><strong>Dirección: </strong>"+ cliente.getDireccion() +"</p>\n" +
                "                <p><strong>Localidad: </strong>"+ cliente.getLocalidad() +"</p>\n" +
                "                <p><strong>Provincia: </strong>"+ cliente.getProvincia() +"</p>\n" +
                "                <p><strong>Teléfono: </strong>"+ cliente.getMovil() +"</p>\n" +
                "                <p><strong>Correo: </strong>"+ cliente.getEmail() +"</p>\n" +
                "                <p><strong>Fecha pedido: </strong>"+ Utils.formatearFecha(pedido.getFechaPedido()) +"</p>\n" +
                "                <p><strong>Entrega estimada: </strong>"+ ((pedido.getEstado() == 3)? "Cancelada" : Utils.formatearFecha(pedido.getFechaEstimada())) +"</p>\n" +
                "                <p><strong>Comentarios: </strong>"+ pedido.getComentario() +"</p>\n" +
                "                <p>El resto de detalles sobre el pedido los encontrarás en la APP.</p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "        <div class=\"footer\">\n" +
                "            <p>Le deseamos un buen día :)</p>\n" +
                "            <p>Email de empresa: <a href=\"mailto:fernanshopmz@gmail.com\">fernanshopmz@gmail.com</a></p>\n" +
                "            <p>Redes sociales:</p>\n" +
                "            <p>\n" +
                "                <a href=\"http://facebook.com\">Facebook</a> |\n" +
                "                <a href=\"http://instagram.com\">Instagram</a>\n" +
                "            </p>\n" +
                "            <p id=\"derechos\">&copy; 2025 FernanShopMZ. Todos los derechos reservados.</p>\n" +
                "            <div id=\"creditos\">\n" +
                "                <h3>Práctica Realizada por:</h3>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1fG-SZVLy7ro9E0eHXN7-obQcf9v1ETBY/view?usp=drive_link\">Mireya Cueto Garrido</a></p>\n" +
                "                <p><a href=\"https://drive.google.com/file/d/1DgSO2qZMh6u2PS6zVmm_C7uw6MzhAYvz/view?usp=drive_link\">Zamira Suriel Matías</a></p>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
        return htmlcode;
    }
}
