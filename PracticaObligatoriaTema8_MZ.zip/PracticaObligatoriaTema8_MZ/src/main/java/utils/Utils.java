package utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    public static void pulsaParaContinuar() {
        System.out.print("Pulsa para continuar... ");
        new Scanner(System.in).nextLine();
        System.out.println();
    }

    public static void loading() {
        System.out.print("Cargando ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void incluirAlPedido() {
        System.out.print("Añadiendo Al Pedido ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void cerrandoSesion() {
        System.out.print("  · Cerrando Sesión ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    public static void enter() {
        System.out.print("Pulsa ENTER ");
        new Scanner(System.in).nextLine();
    }

    //Función que limpia la pantalla:
    public static void limpiaPantalla() {
        for (int i = 0; i < 100; i++) {
            System.out.println();
        }
    }

    //Función que espera un poco antes de pintar algo:
    public static void esperaProducto(){
        try {
            Thread.sleep(750);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    public static void mensajeOpcionIncorrecta(){
        System.out.println("   · Opción introducida incorrecta, vuelve a introducir la opción.");
    }

    public static void mensajeDatoIncorrecto(){
        System.out.println("   · El dato introducido no es válido.");
    }

    //Función quita acentos:
    public static String quitarAcentos(String texto) {
        // Reemplazar caracteres acentuados por su versión sin acento
        texto = texto.replace("á", "a")
                .replace("é", "e")
                .replace("í", "i")
                .replace("ó", "o")
                .replace("ú", "u")
                .replace("Á", "A")
                .replace("É", "E")
                .replace("Í", "I")
                .replace("Ó", "O")
                .replace("Ú", "U")
                .replace("à", "a")
                .replace("è", "e")
                .replace("ì", "i")
                .replace("ò", "o")
                .replace("ù", "u")
                .replace("À", "A")
                .replace("È", "E")
                .replace("Ì", "I")
                .replace("Ò", "O")
                .replace("Ù", "U")
                .replace("ä", "a")
                .replace("ë", "e")
                .replace("ï", "i")
                .replace("ö", "o")
                .replace("ü", "u")
                .replace("Ä", "A")
                .replace("Ë", "E")
                .replace("Ï", "I")
                .replace("Ö", "O")
                .replace("Ü", "U");
        return texto;
    }

    //metodo para comprobar un email:
    public static boolean validarEmail(String email) {
        // Patrón para validar email
        String patron = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    //Función que genera el token de validación de registro (para usarlo por email):
    public static String generaNumeroValidacion() {
        String token = String.valueOf((int) (Math.random() * 10000));
        for (int i = 0; i <= 7 - token.length(); i++) {
            token = "0" + token;
        }
        return token;
    }

    public static String claveAsteriscos(String clave) {
        return "*".repeat(clave.length());
    }

    public static void saliendo() {
        System.out.print("  · Saliendo ");
        for (int i = 0; i < 4; i++) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.print(". ");
        }
        System.out.println();
    }

    //metodo que arregla el precio en cuanto a formato:
    public static String precioArreglado(float precio) {
        return String.format("%.2f", precio);
    }

    //metodo que formatea una fecha a dd-mm-yyyy:
    public static String formatearFecha(LocalDateTime fecha) {
        //define el formato deseado
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //devuelve la fecha en el formato especificado
        return fecha.format(formato);
    }

    //metodo que comprueba si un string es número (se usa para las validaciones de datos
    // en los registros, tal vez deberíamos ponerlo en un Utils):
    public static boolean esNumero(String num) {
        return num.matches("[0-9]+");
    }

    //metodo para validar si una fecha es válida:
    public static boolean esFechaValida(int dia, int mes, int anio) {
        // Validar rango de mes y día
        return mes >= 1 && mes <= 12;
    }

    public static void datoModificado() {
        System.out.print("    · Dato modificado con éxito :)");
        try {
            Thread.sleep(1750);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println();
    }

    public static String formateaFechaString(String fecha) {
        //año-mes-dia --> dia-mes-año
        String resultado = fecha.substring(8) + "/" +
                fecha.substring(5,7) + "/" +
                fecha.substring(0,4);
        return resultado;
    }

    public static String devuelveStringEstado(int estado) {
        return switch (estado) {
            case 1 -> "En Preparación";
            case 2 -> "Enviado";
            case 3 -> "Cancelado";
            case 4 -> "Entregado";
            default -> "";
        };
    }
}
