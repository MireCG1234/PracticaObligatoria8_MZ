package utils;

import controlador.Controlador;
import models.Pedido;

public class Menus {

    public static void logo() {
        System.out.println("""
                ╔═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
                ║  ╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗  ║
                ║  ║                                                                                                                               ║  ║
                ║  ║          ^                                                                                                         ^          ║  ║
                ║  ║         / \\                                                                                                       / \\         ║  ║
                ║  ║        /___\\        ███████╗███████╗██████╗ ███╗   ██╗ █████╗ ███╗   ██╗███████╗██╗  ██╗ ██████╗ ██████╗         /___\\        ║  ║
                ║  ║        |   |        ██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗████╗  ██║██╔════╝██║  ██║██╔═══██╗██╔══██╗        |   |        ║  ║
                ║  ║        |   |        █████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██╔██╗ ██║███████╗███████║██║   ██║██████╔╝        |   |        ║  ║
                ║  ║        |   |        ██╔══╝  ██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║╚██╗██║╚════██║██╔══██║██║   ██║██╔═══╝         |   |        ║  ║
                ║  ║        |___|        ██║     ███████╗██║  ██║██║ ╚████║██║  ██║██║ ╚████║███████║██║  ██║╚██████╔╝██║             |___|        ║  ║
                ║  ║        |___|        ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝             |___|        ║  ║
                ║  ║        |||||                                     ZAMIRA SURIEL y MIREYA CUETO                                    |||||        ║  ║
                ║  ║         \\_/                                                                                                       \\_/         ║  ║
                ║  ║                                                                                                                               ║  ║
                ║  ╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝  ║
                ╚═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
                """);
    }

    public static void menuPrincipalConsola() {
        System.out.println("""
                ╔══════════════════════════════════╗
                ║          MENÚ PRINCIPAL          ║
                ╠══════════════════════════════════╣
                ║       0. Ver Catálogo.           ║
                ║       1. Iniciar sesión.         ║
                ║       2. Registrarse.            ║
                ╚══════════════════════════════════╝
                """);
    }

    public static void menuClienteConsola(String nombre, int numPedidos) {
        System.out.printf("""
                ╔═════════════════════════════════════════════════╗
                ║                   MENÚ CLIENTE                  ║
                ╠═════════════════════════════════════════════════╣
                ║       1. Consultar catálogo de productos.       ║
                ║       2. Realizar un pedido.                    ║
                ║       3. Ver mis pedidos.                       ║
                ║       4. Ver mis datos personales.              ║
                ║       5. Modificar mis datos personales.        ║
                ║       6. Cerrar sesión.                         ║
                ╚═════════════════════════════════════════════════╝
                """);
    }

    public static void submenuConsultaProductosConsola() {
        System.out.println("""
                ╔═════════════════════════════════════════════════╗
                ║                SUBMENÚ PRODUCTOS                ║
                ╠═════════════════════════════════════════════════╣
                ║       1. Ver todo el catálogo.                  ║
                ║       2. Búsqueda por marca.                    ║
                ║       3. Búsqueda por modelo.                   ║
                ║       4. Búsqueda por descripción.              ║
                ║       5. Búsqueda por término.                  ║
                ║       6. Búsqueda por precio.                   ║
                ║       7. Salir.                                 ║
                ╚═════════════════════════════════════════════════╝
                """);
    }

    public static void submenuRealizarPedidoConsola(int numProductos) {
        System.out.printf("""
                Actualmente %s
                ╔═════════════════════════════════════════════════╗
                ║                SUBMENÚ PEDIDOS                  ║
                ╠═════════════════════════════════════════════════╣
                ║       1. Inserta un producto en el carro.       ║
                ║       2. Ver el carro.                          ║
                ║       3. Eliminar un producto del carro.        ║
                ║       4. Confirmar el pedido.                   ║
                ║       5. Cancelar el pedido.                    ║
                ║       6. Salir.                                 ║
                ╚═════════════════════════════════════════════════╝
                """, ((numProductos != 0)? "tiene " + numProductos + " productos en su carro."
                : "no tiene productos en su carro"));
    }

    public static void menuTrabajadorConsola() {
        System.out.printf("""
                ╔═══════════════════════════════════════════════════════════════╗
                ║                        MENÚ TRABAJADOR                        ║
                ╠═══════════════════════════════════════════════════════════════╣
                ║       1. Consultar los pedidos asignados.                     ║
                ║       2. Modificar el estado de un pedido.                    ║
                ║       3. Consultar el catálogo de productos.                  ║
                ║       4. Modificar un producto del catálogo.                  ║
                ║       5. Ver el histórico de pedidos terminados.              ║
                ║       6. Ver mi perfil.                                       ║
                ║       7. Modificar mis datos personales.                      ║
                ║       8. Cerrar sesión.                                       ║
                ╚═══════════════════════════════════════════════════════════════╝
                """);
    }

    public static void submenuModificarPedidoConsola(int numProductos) {
        System.out.println("""
                ╔═════════════════════════════════════════════════╗
                ║       1. Modificar el estado.                   ║
                ║       2. Añadir un comentario.                  ║
                ╚═════════════════════════════════════════════════╝
                """);
    }

    public static void submenuCambiaEstadoConsola() {
        System.out.println("""
                ╔════════════════════════════════╗
                ║      SELECCIONA EL ESTADO      ║
                ╠════════════════════════════════╣
                ║       1. En Preparación        ║
                ║       2. Enviado               ║
                ║       3. Cancelado             ║
                ║       4. Entregado             ║
                ╚════════════════════════════════╝
                """);
    }

    public static void menuAdministradorConsola() {
        System.out.println("""
                ╔═════════════════════════════════════════════════════════╗
                ║                    MENÚ ADMINISTRADOR                   ║
                ╠═════════════════════════════════════════════════════════╣
                ║       1. Ver todo el catálogo.                          ║
                ║       2. Editar un producto.                            ║
                ║       3. Ver resumen de todos los clientes.             ║
                ║       4. Ver resumen de todos los pedidos.              ║
                ║       5. Ver resumen de todos los trabajadores.         ║
                ║       6. Ver estadísticas de la APP.                    ║
                ║       7. Modificar el estado de un pedido.              ║
                ║       8. Dar de alta a un trabajador.                   ║
                ║       9. Dar de baja a un trabajador.                   ║
                ║      10. Asignar un pedido a un trabajador.             ║
                ║      11. Asignar ID Telegram a un Trabajador.           ║
                ║      12. Mostrar configuración del programa.            ║
                ║      13. Enviar listado de pedidos por correo.          ║
                ║      14. Realizar copia de seguridad del programa.      ║
                ║      15. Cerrar sesión.                                 ║
                ╚═════════════════════════════════════════════════════════╝
                """);
    }

    private static void menuEstadisticasAPP(int numClientes, int numTrabajadores, int numPedidos,
       int numPedidosPendientes, int numPedidosCompletadosCancelados, int numPedidosSinAsignar) {
        System.out.printf("""
                ╔═════════════════════════════════════════════════════════════╗
                ║                ESTADÍSTICAS DE LA APLICACIÓN                ║
                ╠═════════════════════════════════════════════════════════════╣
                ║      Número de Clientes: %4d                               ║
                ║      Número de Trabajadores: %4d                           ║
                ║      Número de Pedidos: %4d                                ║
                ║      Número de Pedidos Pendientes: %4d                     ║
                ║      Número de Pedidos Completados o Cancelados: %4d       ║
                ║      Número de Pedidos Sin Asignar: %4d                    ║
                ╚═════════════════════════════════════════════════════════════╝
                """,numClientes, numTrabajadores, numPedidos, numPedidosPendientes,
                        numPedidosCompletadosCancelados, numPedidosSinAsignar);

    }

    public static void menuCambiarDatosCliente() {
        System.out.println("""
                
                ╔══════════════════════════╗
                ║       CAMBIAR DATOS      ║
                ╠══════════════════════════╣
                ║       1. Email.          ║
                ║       2. Clave.          ║
                ║       3. Nombre.         ║
                ║       4. Dirección.      ║
                ║       5. Localidad.      ║
                ║       6. Provincia.      ║
                ║       7. Teléfono.       ║
                ║       8. SALIR.          ║
                ╚══════════════════════════╝
                """);
    }

    public static void menuCambiarDatosTrabajador() {
        System.out.println("""
                ╔══════════════════════════╗
                ║       CAMBIAR DATOS      ║
                ╠══════════════════════════╣
                ║       1. Email.          ║
                ║       2. Clave.          ║
                ║       3. Nombre.         ║
                ║       4. Teléfono.       ║
                ║       5. IdTelegram.     ║
                ║       6. SALIR.          ║
                ╚══════════════════════════╝
                """);
    }

    public static void menuCambiaDatosProducto() {
        System.out.print("""
                ╔════════════════════════════════════╗
                ║       CAMBIAR DATOS PRODUCTO       ║
                ╠════════════════════════════════════╣
                ║       1. Marca.                    ║
                ║       2. Modelo.                   ║
                ║       3. Descripción.              ║
                ║       4. Precio.                   ║
                ║       5. SALIR.                    ║
                ╚════════════════════════════════════╝
                Introduce la opción deseada:\s""");
    }

    public static void menuEstadisticasAPP(Controlador controlador) {
        System.out.printf("""
                ╔══════════════════════════════════════════════════════════════════╗
                ║                       ESTADÍSTICAS DE APP                        ║
                ╠══════════════════════════════════════════════════════════════════╣
                ║       1. Número de Clientes: %d                                   ║
                ║       2. Número de Trabajadores: %d                               ║
                ║       3. Número de Pedidos: %d                                    ║
                ║       4. Número de Pedidos Pendientes: %d                         ║
                ║       4. Número de Pedidos Completados o Cancelados: %d           ║
                ║       4. Número de Pedidos sin Asignar: %d                        ║
                ╚══════════════════════════════════════════════════════════════════╝
                """,
                controlador.getClientes().size(),
                controlador.getTrabajadores().size(),
                controlador.getPedidosTotales().size(),
                controlador.getPedidosClientesSinCancelarEntregar().size(),
                controlador.getPedidosClientesCanceladosEntregados().size(),
                controlador.getPedidosSinAsignar().size());

    }


    public static void menuConsultaProductosInvitado() {
        System.out.println("""
                ╔═════════════════════════════════════════════════╗
                ║              CATÁLOGO DE PRODUCTOS              ║
                ╠═════════════════════════════════════════════════╣
                ║       1. Ver todo el catálogo.                  ║
                ║       2. Búsqueda por marca.                    ║
                ║       3. Búsqueda por modelo.                   ║
                ║       4. Búsqueda por descripción.              ║
                ║       5. Búsqueda por término.                  ║
                ║       6. Búsqueda por precio.                   ║
                ╚═════════════════════════════════════════════════╝
                """);
    }
}
