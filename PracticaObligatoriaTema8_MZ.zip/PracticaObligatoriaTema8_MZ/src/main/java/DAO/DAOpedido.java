package DAO;

import controlador.Controlador;
import models.Cliente;
import models.Pedido;
import models.Producto;
import models.Trabajador;

import java.util.ArrayList;

public interface DAOpedido {

    public boolean insertarPedido(Cliente cliente, Pedido pedido, DAOManager dao);

    public boolean insertarPedidoTrabajador(Trabajador trabajador, Pedido pedido, DAOManager dao);

    public boolean insertarPedidoProducto(Cliente cliente, Pedido pedido, DAOManager dao);

    public boolean modificarPedido(Pedido pedido, DAOManager dao);

    public ArrayList<Pedido> leerPedidosCliente(Controlador controlador, Cliente cliente, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public ArrayList<Pedido> leerPedidosTrabajador(Trabajador trabajador, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public ArrayList<Pedido> leerTodosLosPedidos(DAOManager dao, DAOproductoSQL daOproductoSQL);

    public boolean borraPedido(Pedido pedido, DAOManager dao, DAOproductoSQL daOproductoSQL);

}
