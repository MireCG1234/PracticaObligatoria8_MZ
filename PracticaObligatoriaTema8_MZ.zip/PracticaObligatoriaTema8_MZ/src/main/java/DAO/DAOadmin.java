package DAO;

import controlador.Controlador;
import models.Admin;

import java.util.ArrayList;

public interface DAOadmin {

    public boolean insertarAdmin(Admin admin, DAOManager dao);

    public boolean modificarAdmin(Admin admin, DAOManager dao);

    public ArrayList<Admin> leerTodosAdmins(Controlador controlador, DAOManager dao, DAOadminSQL daOadminSQL);

    public boolean borraAdmin(Admin admin, DAOManager dao, DAOadminSQL daOadminSQL);

}
