package DAO;

import com.mysql.cj.xdevapi.Client;
import models.Cliente;
import models.Pedido;
import models.Producto;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class DAOproductoSQL implements  DAOproducto {

    @Override
    public boolean insertarProducto(Producto producto, DAOManager dao) {
        try {
            dao.open();
            String sentencia = "INSERT INTO Productos (ID, Marca, Modelo, Descripcion, Precio, Relevancia) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setInt(1, producto.getId());
            ps.setString(2, producto.getMarca());
            ps.setString(3, producto.getModelo());
            ps.setString(4, producto.getDescripcion());
            ps.setFloat(5, producto.getPrecio());
            ps.setInt(6, producto.getRelevancia());
            ps.executeUpdate();
            dao.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean insertarProductoCarrito(Cliente cliente, Producto producto, DAOManager dao) {
        try {
            dao.open();

            Connection conn = dao.getConn();

            // 1. Asegurarse de que el carrito del cliente exista en Carritos
            String insertarCarrito = "INSERT IGNORE INTO Carritos (IDCliente) VALUES (?)";
            try (PreparedStatement psCarrito = conn.prepareStatement(insertarCarrito)) {
                psCarrito.setString(1, cliente.getId());
                psCarrito.executeUpdate();
            }

            // 2. Verificar si el producto ya está en el carrito
            String selectExistente = "SELECT Cantidad FROM Carrito_Producto WHERE IDCarrito = ? AND IDProducto = ?";
            int cantidadActual = 0;

            try (PreparedStatement psSelect = conn.prepareStatement(selectExistente)) {
                psSelect.setString(1, cliente.getId());
                psSelect.setInt(2, producto.getId());
                ResultSet rs = psSelect.executeQuery();
                if (rs.next()) {
                    cantidadActual = rs.getInt("Cantidad");
                }
            }

            if (cantidadActual > 0) {
                // 3a. Si ya existe, actualizar cantidad
                String updateCantidad = "UPDATE Carrito_Producto SET Cantidad = ? WHERE IDCarrito = ? AND IDProducto = ?";
                try (PreparedStatement psUpdate = conn.prepareStatement(updateCantidad)) {
                    psUpdate.setInt(1, cantidadActual + 1);
                    psUpdate.setString(2, cliente.getId());
                    psUpdate.setInt(3, producto.getId());
                    psUpdate.executeUpdate();
                }
            } else {
                // 3b. Si no existe, insertar nueva fila con cantidad 1
                String insertarProductoCarrito = "INSERT INTO Carrito_Producto (IDCarrito, IDProducto, Cantidad) VALUES (?, ?, ?)";
                try (PreparedStatement psInsert = conn.prepareStatement(insertarProductoCarrito)) {
                    psInsert.setString(1, cliente.getId());
                    psInsert.setInt(2, producto.getId());
                    psInsert.setInt(3, 1);
                    psInsert.executeUpdate();
                }
            }

            dao.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public boolean modificarProducto(Producto producto, DAOManager dao) {
        try {
            dao.open();
            String sentencia = "UPDATE Productos SET Marca = ?, Modelo = ?, Descripcion = ?, Precio = ?, Relevancia = ? WHERE ID = ?";
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, producto.getMarca());
            ps.setString(2, producto.getModelo());
            ps.setString(3, producto.getDescripcion());
            ps.setFloat(4, producto.getPrecio());
            ps.setInt(5, producto.getRelevancia());
            ps.setInt(6, producto.getId());
            ps.executeUpdate();
            dao.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public ArrayList<Producto> leerProductosCarrito(Cliente cliente, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentencia = "SELECT p.* FROM Productos p JOIN Carrito_Producto cp ON p.ID = cp.IDProducto WHERE cp.IDCarrito = ?";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, cliente.getId());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto producto = new Producto(
                            rs.getInt("ID"),
                            rs.getString("Marca"),
                            rs.getString("Modelo"),
                            rs.getString("Descripcion"),
                            rs.getFloat("Precio"),
                            rs.getInt("Relevancia")
                    );
                    lista.add(producto);
                }
            }
            dao.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public ArrayList<Producto> leerProductosPedido(Pedido pedido, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentencia = "SELECT p.* FROM Productos p JOIN Pedido_Producto pp ON p.ID = pp.IDProducto WHERE pp.IDPedido = ?";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, pedido.getId());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto producto = new Producto(
                            rs.getInt("ID"),
                            rs.getString("Marca"),
                            rs.getString("Modelo"),
                            rs.getString("Descripcion"),
                            rs.getFloat("Precio"),
                            rs.getInt("Relevancia")
                    );
                    lista.add(producto);
                }
            }
            dao.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public ArrayList<Producto> leerTodosLosProductos(DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentencia = "SELECT * FROM Productos";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto producto = new Producto(
                            rs.getInt("ID"),
                            rs.getString("Marca"),
                            rs.getString("Modelo"),
                            rs.getString("Descripcion"),
                            rs.getFloat("Precio"),
                            rs.getInt("Relevancia")
                    );
                    lista.add(producto);
                }
            }
            dao.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return lista;
    }


    @Override
    public boolean borraProducto(Producto producto, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        try {
            dao.open();
            String sentencia = "DELETE FROM Productos WHERE ID = ?";
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setInt(1, producto.getId());
            int rowsAffected = ps.executeUpdate();
            dao.close();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean borraProductoCarrito(Cliente cliente, Producto producto, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        try {
            dao.open();
            Connection conn = dao.getConn();

            String deleteProducto = "DELETE FROM Carrito_Producto WHERE IDCarrito = ? AND IDProducto = ? LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(deleteProducto);
            ps.setString(1, cliente.getId());
            ps.setInt(2, producto.getId());

            int rowsAffected = ps.executeUpdate();

            dao.close();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public ArrayList<Producto> obtenerProductosPorPedido(String idPedido, DAOManager dao) {
        ArrayList<Producto> productos = new ArrayList<>();
        String sentencia = "SELECT p.ID, p.Marca, p.Modelo, p.Descripcion, p.Precio, p.Relevancia " +
                "FROM Productos p " +
                "JOIN Pedido_Producto pp ON p.ID = pp.IDProducto " +
                "WHERE pp.IDPedido = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, idPedido);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Producto producto = new Producto(
                        rs.getInt("ID"),
                        rs.getString("Marca"),
                        rs.getString("Modelo"),
                        rs.getString("Descripcion"),
                        rs.getFloat("Precio"),
                        rs.getInt("Relevancia")
                );
                productos.add(producto);
            }

            dao.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return productos;
    }

    @Override
    public boolean borraProductosCarrito(Cliente cliente, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        try {
            dao.open();
            Connection conn = dao.getConn();

            String deleteTodosProductos = "DELETE FROM Carrito_Producto WHERE IDCarrito = ?";
            PreparedStatement ps = conn.prepareStatement(deleteTodosProductos);
            ps.setString(1, cliente.getId());

            int rowsAffected = ps.executeUpdate();

            dao.close();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
