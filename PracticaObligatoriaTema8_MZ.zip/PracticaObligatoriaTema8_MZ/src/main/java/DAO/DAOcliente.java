package DAO;

import controlador.Controlador;
import models.Admin;
import models.Cliente;

import java.util.ArrayList;

public interface DAOcliente {

    public boolean insertarCliente(Cliente cliente, DAOManager dao);

    public boolean modificarCliente(Cliente cliente, DAOManager dao);

    public ArrayList<Cliente> leerTodosClientes(Controlador controlador, DAOManager dao, DAOclienteSQL daOclienteSQL,
                                                DAOproductoSQL daOproductoSQL, DAOpedidoSQL daOpedidoSQL);

    public boolean borraCliente(Cliente cliente, DAOManager dao, DAOclienteSQL daOclienteSQL);
}
