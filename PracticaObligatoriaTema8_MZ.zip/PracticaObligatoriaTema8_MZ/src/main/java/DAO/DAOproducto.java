package DAO;

import models.Cliente;
import models.Pedido;
import models.Producto;

import java.util.ArrayList;

public interface DAOproducto {
    public boolean insertarProducto(Producto producto, DAOManager dao);

    public boolean insertarProductoCarrito(Cliente cliente, Producto producto, DAOManager dao);

    public boolean modificarProducto(Producto producto, DAOManager dao);

    public ArrayList<Producto> leerProductosCarrito(Cliente cliente, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public ArrayList<Producto> leerProductosPedido(Pedido pedido, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public ArrayList<Producto> leerTodosLosProductos(DAOManager dao, DAOproductoSQL daOproductoSQL);

    public boolean borraProducto(Producto producto, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public boolean borraProductoCarrito(Cliente cliente, Producto producto, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public boolean borraProductosCarrito(Cliente cliente, DAOManager dao, DAOproductoSQL daOproductoSQL);

    public ArrayList<Producto> obtenerProductosPorPedido(String idPedido, DAOManager dao);
}
