package DAO;

import controlador.Controlador;
import models.Cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class DAOclienteSQL implements DAOcliente {

    @Override
    public boolean insertarCliente(Cliente cliente, DAOManager dao) {
        String sql = "INSERT INTO Clientes (ID, Correo, Pass, Nombre, Localidad, Provincia, Direccion, Movil) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, cliente.getId());
            ps.setString(2, cliente.getEmail());
            ps.setString(3, cliente.getClave());
            ps.setString(4, cliente.getNombre());
            ps.setString(5, cliente.getLocalidad());
            ps.setString(6, cliente.getProvincia());
            ps.setString(7, cliente.getDireccion());
            ps.setInt(8, cliente.getMovil());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public boolean modificarCliente(Cliente cliente, DAOManager dao) {
        String sql = "UPDATE Clientes SET Correo = ?, Pass = ?, Nombre = ?, Localidad = ?, Provincia = ?, Direccion = ?, Movil = ? " +
                "WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, cliente.getEmail());
            ps.setString(2, cliente.getClave());
            ps.setString(3, cliente.getNombre());
            ps.setString(4, cliente.getLocalidad());
            ps.setString(5, cliente.getProvincia());
            ps.setString(6, cliente.getDireccion());
            ps.setInt(7, cliente.getMovil());
            ps.setString(8, cliente.getId());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public ArrayList<Cliente> leerTodosClientes(Controlador controlador, DAOManager dao, DAOclienteSQL daOclienteSQL,
                                                DAOproductoSQL daOproductoSQL, DAOpedidoSQL daOpedidoSQL) {
        ArrayList<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM Clientes";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cliente cliente = new Cliente(
                        rs.getString("Correo"),
                        rs.getString("Pass"),
                        rs.getString("Nombre"),
                        rs.getString("Localidad"),
                        rs.getString("Provincia"),
                        rs.getString("Direccion"),
                        rs.getInt("Movil"),
                        controlador
                );
                // Asegúrate de que puedas establecer manualmente el ID si es necesario:
                cliente.setId(rs.getString("ID"));
                cliente.setCarro(daOproductoSQL.leerProductosCarrito(cliente,dao,daOproductoSQL));
                cliente.setPedidos(daOpedidoSQL.leerPedidosCliente(controlador,cliente,dao,daOproductoSQL));
                clientes.add(cliente);
            }

            dao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return clientes;
    }


    @Override
    public boolean borraCliente(Cliente cliente, DAOManager dao, DAOclienteSQL daOclienteSQL) {
        String sql = "DELETE FROM Clientes WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, cliente.getId());
            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}
