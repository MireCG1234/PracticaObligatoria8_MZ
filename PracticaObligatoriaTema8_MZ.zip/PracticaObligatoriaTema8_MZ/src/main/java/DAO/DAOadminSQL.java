package DAO;

import controlador.Controlador;
import models.Admin;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOadminSQL implements  DAOadmin{
    @Override
    public boolean insertarAdmin(Admin admin, DAOManager dao) {
        String sql = "INSERT INTO Admins (ID, Nombre, Clave, Email) VALUES (?, ?, ?, ?)";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, admin.getId());
            ps.setString(2, admin.getNombre());
            ps.setString(3, admin.getClave());
            ps.setString(4, admin.getEmail());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public boolean modificarAdmin(Admin admin, DAOManager dao) {
        String sql = "UPDATE Admins SET Nombre = ?, Clave = ?, Email = ? WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, admin.getNombre());
            ps.setString(2, admin.getClave());
            ps.setString(3, admin.getEmail());
            ps.setString(4, admin.getId());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public ArrayList<Admin> leerTodosAdmins(Controlador controlador, DAOManager dao, DAOadminSQL daOadminSQL) {
        ArrayList<Admin> admins = new ArrayList<>();
        String sql = "SELECT * FROM Admins";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Admin admin = new Admin(
                        rs.getString("Nombre"),
                        rs.getString("Pass"),
                        rs.getString("Correo"),
                        controlador
                );
                admin.setId(rs.getString("ID")); // Asigna el ID recuperado
                admins.add(admin);
            }

            dao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return admins;
    }


    @Override
    public boolean borraAdmin(Admin admin, DAOManager dao, DAOadminSQL daOadminSQL) {
        String sql = "DELETE FROM Admins WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, admin.getId());
            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
