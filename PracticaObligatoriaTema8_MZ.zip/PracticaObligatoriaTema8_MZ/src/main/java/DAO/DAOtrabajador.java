package DAO;

import controlador.Controlador;
import models.Cliente;
import models.Producto;
import models.Trabajador;

import java.util.ArrayList;

public interface DAOtrabajador {

    public boolean insertarTrabajador(Trabajador trabajador, DAOManager dao);

    public boolean modificarTrabajador(Trabajador trabajador, DAOManager dao);

    public ArrayList<Trabajador> leerTodosTrabajadores(Controlador controlador, DAOManager dao, DAOtrabajadorSQL daOtrabajadorSQL,
                                                       DAOproductoSQL daOproductoSQL, DAOpedidoSQL daOpedidoSQL);

    public boolean borraTrabajador(Trabajador trabajador, DAOManager dao, DAOtrabajadorSQL daOtrabajadorSQL);

}
