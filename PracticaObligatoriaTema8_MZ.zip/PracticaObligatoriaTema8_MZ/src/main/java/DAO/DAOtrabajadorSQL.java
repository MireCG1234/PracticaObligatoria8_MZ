package DAO;

import controlador.Controlador;
import models.Pedido;
import models.Producto;
import models.Trabajador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOtrabajadorSQL implements  DAOtrabajador {
    @Override
    public boolean insertarTrabajador(Trabajador trabajador, DAOManager dao) {
        String sql = "INSERT INTO Trabajadores (ID, Nombre, Pass, Correo, Movil, IdTelegram) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, trabajador.getId());
            ps.setString(2, trabajador.getNombre());
            ps.setString(3, trabajador.getClave());
            ps.setString(4, trabajador.getEmail());
            ps.setInt(5, trabajador.getMovil());
            ps.setString(6, trabajador.getIdTelegram());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public boolean modificarTrabajador(Trabajador trabajador, DAOManager dao) {
        String sql = "UPDATE Trabajadores SET Nombre = ?, Pass = ?, Correo = ?, Movil = ?, IdTelegram = ? WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, trabajador.getNombre());
            ps.setString(2, trabajador.getClave());
            ps.setString(3, trabajador.getEmail());
            ps.setInt(4, trabajador.getMovil());
            ps.setString(5, trabajador.getIdTelegram());
            ps.setString(6, trabajador.getId());

            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //Este método también se trae todos los pedidos asignados al trabajador con sus productos:
    @Override
    public ArrayList<Trabajador> leerTodosTrabajadores(Controlador controlador, DAOManager dao, DAOtrabajadorSQL daOtrabajadorSQL,
                                                       DAOproductoSQL daOproductoSQL, DAOpedidoSQL daOpedidoSQL) {
        ArrayList<Trabajador> trabajadores = new ArrayList<>();
        String sql = "SELECT * FROM Trabajadores";
        try {
            dao.open();
            Connection conn = dao.getConn();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                // Crear objeto Trabajador
                Trabajador trabajador = new Trabajador(
                        rs.getString("Nombre"),
                        rs.getString("Pass"),
                        rs.getString("Correo"),
                        rs.getInt("Movil"),
                        controlador
                );
                trabajador.setId(rs.getString("ID"));
                trabajador.setIdTelegram(rs.getString("IdTelegram"));

                // Obtenemos los pedidos asignados del trabajador
                String sqlPedidos = "SELECT IDPedido FROM Pedido_Trabajador WHERE IDTrabajador = ?";
                PreparedStatement psPedidos = conn.prepareStatement(sqlPedidos);
                psPedidos.setString(1, trabajador.getId());
                ResultSet rsPedidos = psPedidos.executeQuery();

                while (rsPedidos.next()) {
                    String idPedido = rsPedidos.getString("IDPedido");

                    // Obtener el pedido completo con sus productos
                    String sqlPedido = "SELECT * FROM Pedidos WHERE ID = ?";
                    PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
                    psPedido.setString(1, idPedido);
                    ResultSet rsPedido = psPedido.executeQuery();

                    if (rsPedido.next()) {
                        ArrayList<Producto> productos = daOproductoSQL.obtenerProductosPorPedido(idPedido, dao);
                        Pedido pedido = new Pedido(
                                rsPedido.getString("ID"),
                                rsPedido.getDate("FechaPedido").toLocalDate().atStartOfDay(),
                                rsPedido.getDate("FechaEntrega").toLocalDate().atStartOfDay(),
                                Integer.parseInt(rsPedido.getString("Estado")),
                                rsPedido.getString("Comentario"),
                                productos
                        );
                        trabajador.getPedidosAsignados().add(pedido);
                    }
                    rsPedido.close();
                    psPedido.close();
                }
                rsPedidos.close();
                psPedidos.close();
                trabajadores.add(trabajador);
            }
            rs.close();
            ps.close();
            dao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return trabajadores;
    }



    @Override
    public boolean borraTrabajador(Trabajador trabajador, DAOManager dao, DAOtrabajadorSQL daOtrabajadorSQL) {
        String sql = "DELETE FROM Trabajadores WHERE ID = ?";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, trabajador.getId());
            ps.executeUpdate();
            dao.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
