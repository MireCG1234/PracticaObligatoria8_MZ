package DAO;

import controlador.Controlador;
import models.Cliente;
import models.Pedido;
import models.Producto;
import models.Trabajador;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DAOpedidoSQL implements DAOpedido{

    @Override
    public boolean insertarPedido(Cliente cliente, Pedido pedido, DAOManager dao) {
        try {
            dao.open();

            // Insertar pedido
            String insertPedido = "INSERT INTO Pedidos (ID, ID_Cliente, FechaPedido, FechaEntrega, Estado, Comentario) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement psPedido = dao.getConn().prepareStatement(insertPedido);
            psPedido.setString(1, pedido.getId());
            psPedido.setString(2, cliente.getId());
            psPedido.setTimestamp(3, Timestamp.valueOf(pedido.getFechaPedido()));
            psPedido.setTimestamp(4, Timestamp.valueOf(pedido.getFechaEstimada()));
            psPedido.setInt(5, pedido.getEstado());
            psPedido.setString(6, pedido.getComentario());
            psPedido.executeUpdate();

            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean insertarPedidoTrabajador(Trabajador trabajador, Pedido pedido, DAOManager dao) {
        try {
            dao.open();

            String insertAsignacion = "INSERT INTO Pedido_Trabajador (IDPedido, IDTrabajador) VALUES (?, ?)";
            PreparedStatement psAsignacion = dao.getConn().prepareStatement(insertAsignacion);
            psAsignacion.setString(1, pedido.getId());
            psAsignacion.setString(2, trabajador.getId());
            psAsignacion.executeUpdate();

            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    //método para devolver un pedido dada la ID de este:
    public Pedido obtenerPedidoPorId(String idPedido, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        Pedido pedido = null;
        String sql = "SELECT * FROM Pedidos WHERE ID = ?";

        try {
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, idPedido);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Obtener campos del pedido
                LocalDateTime fechaPedido = rs.getDate("FechaPedido").toLocalDate().atStartOfDay();
                LocalDateTime fechaEntrega = rs.getDate("FechaEntrega").toLocalDate().atStartOfDay();
                int estado = Integer.parseInt(rs.getString("Estado"));
                String comentario = rs.getString("Comentario");

                // Obtener productos asociados al pedido
                ArrayList<Producto> productos = daoProductoSQL.obtenerProductosPorPedido(idPedido, dao);

                // Crear el objeto Pedido
                pedido = new Pedido(fechaPedido, fechaEntrega, comentario, productos, new Controlador());
                pedido.setId(idPedido); // Si tienes setter
                pedido.setEstado(estado);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return pedido;
    }


    @Override
    public boolean insertarPedidoProducto(Cliente cliente, Pedido pedido, DAOManager dao) {
        try {
            dao.open();

            String insertProducto = "INSERT INTO Pedido_Producto (IDPedido, IDProducto, Cantidad) VALUES (?, ?, ?)";
            PreparedStatement psProducto = dao.getConn().prepareStatement(insertProducto);

            // Insertar una fila por cada unidad del producto
            for (Producto producto : pedido.getProductos()) {
                psProducto.setString(1, pedido.getId());
                psProducto.setInt(2, producto.getId());
                psProducto.setInt(3, 1); // cada entrada representa una sola unidad
                psProducto.executeUpdate();
            }

            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    @Override
    public boolean modificarPedido(Pedido pedido, DAOManager dao) {
        try {
            dao.open();
            String updatePedido = "UPDATE Pedidos SET FechaEntrega = ?, Estado = ?, Comentario = ? WHERE ID = ?";
            PreparedStatement ps = dao.getConn().prepareStatement(updatePedido);
            ps.setTimestamp(1, Timestamp.valueOf(pedido.getFechaEstimada()));
            ps.setInt(2, pedido.getEstado());
            ps.setString(3, pedido.getComentario());
            ps.setString(4, pedido.getId());
            ps.executeUpdate();
            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    @Override
    public ArrayList<Pedido> leerPedidosCliente(Controlador controlador, Cliente cliente, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pedidos WHERE ID_Cliente = ?";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ps.setString(1, cliente.getId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String idPedido = rs.getString("ID");
                ArrayList<Producto> productos = daoProductoSQL.obtenerProductosPorPedido(idPedido, dao);

                Pedido pedido = new Pedido(
                        rs.getString("ID"),
                        rs.getTimestamp("FechaPedido").toLocalDateTime(),
                        rs.getTimestamp("FechaEntrega").toLocalDateTime(),
                        rs.getInt("Estado"),
                        rs.getString("Comentario"),
                        productos
                );
                lista.add(pedido);
            }
            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }


    @Override
    public ArrayList<Pedido> leerPedidosTrabajador(Trabajador trabajador, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pedidos";

        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String idPedido = rs.getString("ID");
                ArrayList<Producto> productos = daoProductoSQL.obtenerProductosPorPedido(idPedido, dao);

                Pedido pedido = new Pedido(
                        rs.getTimestamp("FechaPedido").toLocalDateTime(),
                        rs.getTimestamp("FechaEntrega").toLocalDateTime(),
                        rs.getString("Comentario"),
                        productos,
                        new Controlador() // O el controlador que estés usando para generar IDs
                );
                // Aquí puedes establecer el ID y estado si no lo hace el constructor
                pedido.setId(idPedido);
                pedido.setEstado(rs.getInt("Estado"));
                lista.add(pedido);
            }

            dao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return lista;
    }



    @Override
    public ArrayList<Pedido> leerTodosLosPedidos(DAOManager dao, DAOproductoSQL daoProductoSQL) {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pedidos";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String idPedido = rs.getString("ID");
                ArrayList<Producto> productos = daoProductoSQL.obtenerProductosPorPedido(idPedido, dao);

                Pedido pedido = new Pedido(
                        rs.getTimestamp("FechaPedido").toLocalDateTime(),
                        rs.getTimestamp("FechaEntrega").toLocalDateTime(),
                        rs.getString("Comentario"),
                        productos,
                        new Controlador() // O el que estés usando
                );
                lista.add(pedido);
            }
            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }


    @Override
    public boolean borraPedido(Pedido pedido, DAOManager dao, DAOproductoSQL daoProductoSQL) {
        try {
            dao.open();

            // Borrar primero los productos del pedido
            String deleteProductos = "DELETE FROM Pedidos_Productos WHERE ID_Pedido = ?";
            PreparedStatement ps1 = dao.getConn().prepareStatement(deleteProductos);
            ps1.setString(1, pedido.getId());
            ps1.executeUpdate();

            // Borrar el pedido
            String deletePedido = "DELETE FROM Pedidos WHERE ID = ?";
            PreparedStatement ps2 = dao.getConn().prepareStatement(deletePedido);
            ps2.setString(1, pedido.getId());
            ps2.executeUpdate();

            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
