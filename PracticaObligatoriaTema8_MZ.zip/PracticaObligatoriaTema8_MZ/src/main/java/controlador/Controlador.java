package controlador;

import DAO.*;
import models.*;
import persistencia.Persistencia;
import utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

public class Controlador implements Serializable {

    Persistencia persistencia = new Persistencia();

    //ATRIBUTOS
    private ArrayList<Cliente> clientes;
    private ArrayList<Trabajador> trabajadores;
    private ArrayList<Admin> admins;
    private ArrayList<Producto> catalogo;
    private DAOManager dao;
    private DAOclienteSQL daOclienteSQL;
    private DAOproductoSQL daOproductoSQL;
    private DAOtrabajadorSQL daOtrabajadorSQL;
    private DAOadminSQL daOadminSQL;
    private DAOpedidoSQL daOpedidoSQL;


    //CONSTRUCTORES

    public Controlador() {
        dao = DAOManager.getSinglentonInstance();
        daOproductoSQL = new DAOproductoSQL();
        daOtrabajadorSQL = new DAOtrabajadorSQL();
        daOadminSQL = new DAOadminSQL();
        daOclienteSQL = new DAOclienteSQL();
        daOpedidoSQL = new DAOpedidoSQL();
        try {
            // Carga de datos desde la base de datos
            this.clientes = daOclienteSQL.leerTodosClientes(this, dao, daOclienteSQL, daOproductoSQL,daOpedidoSQL);
            this.trabajadores = daOtrabajadorSQL.leerTodosTrabajadores(this, dao, daOtrabajadorSQL, daOproductoSQL,daOpedidoSQL);
            this.admins = daOadminSQL.leerTodosAdmins(this, dao, daOadminSQL);
            this.catalogo = daOproductoSQL.leerTodosLosProductos(dao, daOproductoSQL);
        } catch (Exception e) {
            // Si ocurre un error, inicializamos las estructuras vacías y reportamos el error
            this.clientes = new ArrayList<>();
            this.trabajadores = new ArrayList<>();
            this.admins = new ArrayList<>();
            this.catalogo = new ArrayList<>();
            e.printStackTrace(); // Puedes cambiar esto por logs o notificaciones
        }
    }


    //GETTERS Y SETTERS

    public DAOManager getDao() {
        return dao;
    }

    public void setDao(DAOManager dao) {
        this.dao = dao;
    }

    public DAOclienteSQL getDaOclienteSQL() {
        return daOclienteSQL;
    }

    public void setDaOclienteSQL(DAOclienteSQL daOclienteSQL) {
        this.daOclienteSQL = daOclienteSQL;
    }

    public DAOproductoSQL getDaOproductoSQL() {
        return daOproductoSQL;
    }

    public void setDaOproductoSQL(DAOproductoSQL daOproductoSQL) {
        this.daOproductoSQL = daOproductoSQL;
    }

    public DAOtrabajadorSQL getDaOtrabajadorSQL() {
        return daOtrabajadorSQL;
    }

    public void setDaOtrabajadorSQL(DAOtrabajadorSQL daOtrabajadorSQL) {
        this.daOtrabajadorSQL = daOtrabajadorSQL;
    }

    public DAOadminSQL getDaOadminSQL() {
        return daOadminSQL;
    }

    public void setDaOadminSQL(DAOadminSQL daOadminSQL) {
        this.daOadminSQL = daOadminSQL;
    }

    public DAOpedidoSQL getDaOpedidoSQL() {
        return daOpedidoSQL;
    }

    public void setDaOpedidoSQL(DAOpedidoSQL daOpedidoSQL) {
        this.daOpedidoSQL = daOpedidoSQL;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<Trabajador> getTrabajadores() {
        return trabajadores;
    }

    public void setTrabajadores(ArrayList<Trabajador> trabajadores) {
        this.trabajadores = trabajadores;
    }

    public ArrayList<Admin> getAdmins() {
        return admins;
    }

    public void setAdmins(ArrayList<Admin> admins) {
        this.admins = admins;
    }

    public ArrayList<Producto> getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(ArrayList<Producto> catalogo) {
        this.catalogo = catalogo;
    }


    //OTROS MÉTODOS
    //HACER LOGIN:
    //método que recorre los arrayList y compara los parámetros, si coinciden devuelve el objeto.
    public Object login(String email, String clave){
        for (Admin admin : admins){
            if (admin.login(email,clave)) return admin;
        }
        for (Trabajador trabajador : trabajadores){
            if (trabajador.login(email,clave)) return trabajador;
        }
        for (Cliente cliente : clientes){
            if (cliente.login(email,clave)) return cliente;
        }
        return null;
    }

    //Método que busca los productos por marca en el catálogo:
    public ArrayList<Producto> buscaProductosByMarca(String marca){
        ArrayList<Producto> resultados = new ArrayList<>();
        for (Producto p : catalogo){
            if (p.getMarca().toLowerCase().contains(marca.toLowerCase())) resultados.add(p);
        }
        return resultados;
    }

    //Método que busca los productos por id en el catálogo:
    public Producto buscaProductoByID(int id){
        for (Producto p : catalogo){
            if (p.getId() == id) return p;
        }
        return null;
    }

    //Método que busca los productos por modelo en el catálogo:
    public ArrayList<Producto> buscaProductosByModelo(String modelo){
        ArrayList<Producto> resultados = new ArrayList<>();
        for (Producto p : catalogo){
            if (p.getModelo().toLowerCase().contains(modelo.toLowerCase())) resultados.add(p);
        }
        return resultados;
    }

    //Método que busca los productos por decripcion en el catálogo:
    public ArrayList<Producto> buscaProductosByDescripcion(String decripcion){
        ArrayList<Producto> resultados = new ArrayList<>();
        for (Producto p : catalogo){
            if (p.getDescripcion().toLowerCase().contains(decripcion.toLowerCase())) resultados.add(p);
        }
        return resultados;
    }

    //Método que busca los productos por término (Marca, Modelo y Descripción) en el catálogo:
    public ArrayList<Producto> buscaProductosByTermino(String termino){
        ArrayList<Producto> resultadosMarca = buscaProductosByMarca(termino);
        ArrayList<Producto> resultadosModelo = buscaProductosByModelo(termino);
        ArrayList<Producto> resultadosDescripcion = buscaProductosByDescripcion(termino);
        ArrayList<Producto> resultados = new ArrayList<>();
        for (Producto p : resultadosMarca){
            if (!existeProductoEnLista(resultados, p))
                resultados.add(p);
        }
        for (Producto p : resultadosModelo){
            if (!existeProductoEnLista(resultados, p))
                resultados.add(p);
        }
        for (Producto p : resultadosDescripcion){
            if (!existeProductoEnLista(resultados, p))
                resultados.add(p);
        }
        return resultados;
    }

    //Método que comprueba si existe ya un producto en una lista por el Id:
    public boolean existeProductoEnLista(ArrayList<Producto> resultados, Producto producto){
        for (Producto p : resultados){
            if (p != null && p.getId() == producto.getId()) return true;
        }
        return false;
    }

    //Método que busca los productos por precio en el catálogo:
    public ArrayList<Producto> buscaProductosByPrecio(float precioMin, float precioMax){
        ArrayList<Producto> resultados = new ArrayList<>();
        for (Producto p : catalogo){
            if (p.getPrecio() >= precioMin && p.getPrecio() <= precioMax) resultados.add(p);
        }
        return resultados;
    }

    //Método que edita un producto:
    public boolean editarProducto(Producto p){
        return false;
    }

    //Método que añade un producto al carrito:
    public boolean addProductoCarrito(Cliente cliente, int idProducto){
        for (Producto p : catalogo){
            if (p.getId() == idProducto){
                cliente.getCarro().add(p);
                return true;
            }
        }
        return false;
    }

    //Método que elimina un producto del carrito:
    public boolean removeProductoCarrito(Cliente cliente, int idProducto, Controlador controlador){
        for (Producto p : cliente.getCarro()){
            if (p.getId() == idProducto){
                cliente.getCarro().remove(p);
                //BORRO EL PRODUCTO DEL CARRITO EN BBDD:
                controlador.getDaOproductoSQL().borraProductoCarrito(cliente,p,controlador.getDao(),controlador.getDaOproductoSQL());
                return true;
            }
        }
        return false;
    }

    //Método que cambia el estado de un pedido (ambos se le pasan por parámetro):
    public boolean cambiaEstadoPedido(Pedido pedido, int nuevoEstado){
        if (nuevoEstado < 1 || nuevoEstado > 4) return false;
        else pedido.setEstado(nuevoEstado);
        return true;
    }

    //Método que busca un pedido por posición en el array -1:
    public boolean buscaPedidoByNum(Cliente cliente, int numPedido){
        try {
            if (cliente.getPedidos().get(numPedido -1) != null) return true;
        } catch (Exception e){
            return  false;
        }
        return false;
    }


    //MÉTODOS DE LOS TRABAJADORES:
    //método que busca el trabajador que menos pedidos tiene, si hay empate no hace nada:
    public Trabajador buscaTrabajadorCandidatoParaAsignar(){
        int numPedidosMenor = Integer.MAX_VALUE;
        int contador = 0;
        for (Trabajador t : trabajadores){
            if (t.getPedidosAsignados() != null && t.getPedidosAsignados().size() == numPedidosMenor){
                contador++;
            }
            if (t.getPedidosAsignados() != null && t.getPedidosAsignados().size() < numPedidosMenor){
                numPedidosMenor = t.getPedidosAsignados().size();
                contador = 0;
            }
        }
        if (contador > 0) return null;
        //Busco de nuevo el trabajador que tiene menos pedidos asignados;
        for (Trabajador t : trabajadores){
            if (t.getPedidosAsignados().size() == numPedidosMenor) return t;
        }
        return null;
    }

    //métodos privados que calculan el número del Id de cada cosa:
    private int generaIdCliente(){
        return (int) ((Math.random()*100000000)+1000000);
    }
    private int generaIdProducto(){
        return (int) (Math.random()*100000000);
    }
    private int generaIdPedido(){
        return (int) ((Math.random()*100000000)+100000);
    }
    private int generaIdAdmin(){
        return (int) ((Math.random()*100)+100);
    }
    private int generaIdTrabajador(){
        return (int) ((Math.random()*10000)+10000);
    }

    //Método que devuelve el id del pedido sin que se repita:
    public String devuelveIdPedido() {
        String idPedido = "";
        do {
            idPedido = String.valueOf(generaIdPedido());
            for (int i = 0; i <= 8 - idPedido.length(); i++) {
                idPedido = "0" + idPedido;
            }
            idPedido = "PE" + idPedido;
        } while (buscaIdPedido(idPedido));
        return idPedido;
    }

    //Método que busca el id del pedido para que no se repita:
    private boolean buscaIdPedido(String idPedido) {
        for (Cliente c:clientes){
            for (Pedido p : c.getPedidos()){
                if (p.getId().equalsIgnoreCase(idPedido)) return true;
            }
        }
        return false;
    }

    //Método que devuelve el id del cliente completo sin que se repita:
    public String devuelveIdCliente(){
        String idCliente = "";
        do {
            idCliente = String.valueOf(generaIdCliente());
            for (int i = 0; i <= 8 - idCliente.length(); i++) {
                idCliente = "0" + idCliente;
            }
            idCliente = "CL" + idCliente;
        } while (buscaIdCliente(idCliente));
        return idCliente;
    }

    //Método que devuelve el id del Administrador sin que se repita:
    public String devuelveIdAdmin() {
        String idAdmin = "";
        do {
            idAdmin = String.valueOf(generaIdAdmin());
            for (int i = 0; i <= 3 - idAdmin.length(); i++) {
                idAdmin = "0" + idAdmin;
            }
            idAdmin = "AD" + idAdmin;
        } while (buscaIdCliente(idAdmin));
        return idAdmin;
    }

    //Método que devuelve el id del Trabajador sin que se repita:
    public String devuelveIdTrabajador() {
        String idTrabaj = "";
        do {
            idTrabaj = String.valueOf(generaIdTrabajador());
            for (int i = 0; i <= 5 - idTrabaj.length(); i++) {
                idTrabaj = "0" + idTrabaj;
            }
            idTrabaj = "TR" + idTrabaj;
        } while (buscaIdCliente(idTrabaj));
        return idTrabaj;
    }

    //MÉTODOS DE LOS CLIENTES Y USUARIOS:
    //Método que busca el id del cliente para que no se repita:
    private boolean buscaIdCliente(String idCliente) {
        if (clientes == null) return false;
        for (Cliente c : clientes){
            if (c.getId().equalsIgnoreCase(idCliente)) return true;
        }
        return false;
    }

    //método que permite saber si un email está registrado o no:
    public boolean buscaEmailRegistrado(String email) {
        for (Admin a : admins){
            if (a.getEmail().equalsIgnoreCase(email)) return true;
        }
        for (Trabajador t : trabajadores){
            if (t.getEmail().equalsIgnoreCase(email)) return true;
        }
        for (Cliente c : clientes){
            if (c.getEmail().equalsIgnoreCase(email)) return true;
        }
        return false;
    }

    //método que busca un email y clave de un usuario para hacer login:
    public Object devuelveUsuario(String email, String clave) {
        for (Admin a : admins){
            if (a.getEmail().equalsIgnoreCase(email) && a.getClave().equals(clave)) return (Admin) a;
        }
        for (Trabajador t : trabajadores){
            if (t.getEmail().equalsIgnoreCase(email) && t.getClave().equals(clave)) return (Trabajador) t;
        }
        for (Cliente c : clientes){
            if (c.getEmail().equalsIgnoreCase(email) && c.getClave().equals(clave)) return (Cliente) c;
        }
        return null;
    }
    //MÉTODOS DE LOS PRODUCTOS:
    //método que busca un producto por una ID introducida:
    public Producto buscaProductoById(int idProducto) {
        for (Producto p : catalogo){
            if (p.getId() == idProducto) return p;
        }
        return null;
    }

    //Método para buscar un producto del carrito:
    public Producto buscaProductoByIdCarro(Cliente cliente, int idProducto) {
        for (Producto p : cliente.getCarro()){
            if (p.getId() == idProducto){
                return p;
            }
        }
        return null;
    }
    //MÉTODOS DE LOS PEDIDOS:
    //método que confirma un pedido de un cliente:
    public Pedido confirmaPedidoCliente(Cliente cliente, Controlador controlador) {
        try {
            ArrayList<Producto> prodTemp = new ArrayList<>();
            // Copiamos los productos del carrito sin referenciarlos directamente:
            for (Producto p : cliente.getCarro()) {
                prodTemp.add(new Producto(p)); // Utilizamos el constructor copia para copiar los productos del carro.
            }
            Pedido temp = new Pedido(prodTemp, controlador); //hago un nuevo pedido con el carro
            cliente.getCarro().clear(); //borro todos los productos del carrito
            return temp;
        } catch (Exception e){
            return null;
        }
    }

    //metodo que valida el dato introducido para que el precio no sea negativo (comprueba si está vacío y lo pasa a Float):
    public boolean validaPrecio(String datoModificado){
        if (datoModificado.isEmpty()) return false;
        try {
            return Float.parseFloat(datoModificado) >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //Método que valida si un String está vacío:
    public boolean validaStringIntroducido(String datoNuevo) {
        return !datoNuevo.isEmpty();
    }

    //método que devuelve un array de pedidos sin cancelar o entregar:
    public ArrayList<Pedido> getPedidosClientesSinCancelarEntregar() {
        ArrayList<Pedido> resultado = new ArrayList<>();
        for (Cliente c : clientes){
            if (!c.getPedidos().isEmpty()){
                for (Pedido p : c.getPedidos()){
                    if (p.getEstado() != 3 && p.getEstado() != 4) resultado.add(p);
                }
            }
        }
        ordenaPorFechaReciente(resultado);
        return resultado;
    }

    //método que ordena un array de pedidos por fecha reciente:
    private void ordenaPorFechaReciente(ArrayList<Pedido> pedidos) {
        //pedidosCancelados.sort((p1, p2) -> p2.getFechaPedido().isAfter(p1.getFechaPedido()) ? 1 : (p2.getFechaPedido().isBefore(p1.getFechaPedido()) ? -1 : 0));
        pedidos.sort((p1, p2) -> p2.getFechaPedido().compareTo(p1.getFechaPedido()));
    }

    //método que devuelve un cliente partiendo del ID de un pedido:
    public Cliente getClientePorIdPedido(String id) {
        for (Cliente c : clientes){
            for (Pedido p : c.getPedidos()){
                if (p.getId().equalsIgnoreCase(id)) return c;
            }
        }
        return null;
    }

    //método que asigna un pedido a un trabajador:
    public boolean asignaPedidoTrabajador(Pedido temp) {
        if (buscaTrabajadorCandidatoParaAsignar() == null) return false;
        Trabajador t = buscaTrabajadorCandidatoParaAsignar();
        t.getPedidosAsignados().add(temp);
        return true;
    }

    //método que da de alta un nuevo trabajador:
    public void insertaTrabajador(Trabajador trabajador) {
            trabajadores.add(new Trabajador(trabajador));
    }

    //método que pinta la información de un trabajador:
    public String pintaTrabajadores() {
        int cont = 1;
        String resultado =  " ╔════════════════════════════════════════════════════════════════════════════════════════════════════════╗\n" +
                            " ║ TRABAJADORES EN LA PLANTILLA:                                                                          ║\n" +
                            " ╠════════════════════════════════════════════════════════════════════════════════════════════════════════╣\n";
        if (clientes.isEmpty()) resultado +=
                            " ║ NO HAY TRABAJADORES TODAVÍA EN LA APP                                                                  ║\n";
        for (Trabajador t : trabajadores){
            resultado += "\t\t" + cont + ".- " + t.getNombre() + " (" + t.getPedidosAsignados().size() + " pedidos): "
                    + t.getEmail() + " | ID: " + t.getId() + "\n";
            cont++;
        }
        resultado += " ╚════════════════════════════════════════════════════════════════════════════════════════════════════════╝\n";
        return resultado;
    }

    //método que recopila los pedidos de los clientes y los pinta separados por estado:
    public String pintaPedidos() {
        int cont = 1;
        String resultado =  " ╔═════════════════════════════════════════════════════════════════════════════════════════════╗\n" +
                            " ║ PEDIDOS PENDIENTES DE LA APP:                                                               ║\n" +
                            " ╠═════════════════════════════════════════════════════════════════════════════════════════════╣\n";
        if (getPedidosTotales().isEmpty()) resultado +=
                            " ║ NO HAY PEDIDOS TODAVÍA EN LA APP                                                            ║\n";
        else{
            for (Cliente c : clientes){
                for (Pedido p : c.getPedidos()){
                    resultado += "\t" + cont + ".- " + p.getId() + " (" + p.pintaEstado(p.getEstado()) + ") | FP: " +
                            Utils.formatearFecha(p.getFechaPedido()) + " (" + p.getProductos().size() + " productos).\n";
                    cont++;
                }
            }
        }
        resultado += " ╚═════════════════════════════════════════════════════════════════════════════════════════════╝\n";
        return resultado;
    }

    //método que pinta la información de un cliente:
    public String pintaClientes() {
        int cont = 1;
        String resultado =  " ╔══════════════════════════════════════════════════════════════════════════════════════════════╗\n" +
                " ║ CLIENTES EN LA APP:                                                                          ║\n" +
                " ╠══════════════════════════════════════════════════════════════════════════════════════════════╣\n";
        if (clientes.isEmpty()) resultado +=
                " ║ NO HAY CLIENTES TODAVÍA EN LA APP                                                            ║\n";
        for (Cliente c : clientes){
            resultado += "\t" + cont + ".- " + c.getNombre() + " (" + c.getPedidos().size() + " pedidos): "
                    + c.getEmail() + " | ID: " + c.getId() + "\n";
            cont++;
        }
        resultado += " ╚══════════════════════════════════════════════════════════════════════════════════════════════╝\n";
        return resultado;
    }

    //método que elimina un trabajador pasándole la ID:
    public boolean eliminaTrabajadorPorId(String idTrabajador) {
        for (Trabajador t : trabajadores){
            if (t.getId().equalsIgnoreCase(idTrabajador)){
                trabajadores.remove(t);
                return true;
            }
        }
        return false;
    }

    //método para asignar una ID de Telegram a un trabajador desde el administrador:
    public boolean asignaIdTelegram(String idTelegram, String idTrab) {
        for (Trabajador t : trabajadores){
            if (t.getId().equalsIgnoreCase(idTrab)){
                if (t.getIdTelegram().isEmpty()){
                    t.setIdTelegram(idTelegram);
                    return true;
                }
            }
        }
        return false;
    }

    //Método que devuelve un array con los pedidos de cancelados y entregados de los clientes:
    public ArrayList<Pedido> getPedidosClientesCanceladosEntregados() {
        ArrayList<Pedido> resultado = new ArrayList<>();
        for (Cliente c : clientes){
            if (!c.getPedidos().isEmpty()){
                for (Pedido p : c.getPedidos()){
                    if (p.getEstado() == 3 || p.getEstado() == 4) resultado.add(p);
                }
            }
        }
        ordenaPorFechaReciente(resultado);
        return resultado;
    }

    //Método que devuelve un array con los pedidos sin asignar:
    public ArrayList<Pedido> getPedidosSinAsignar() {
        ArrayList<Pedido> resultado = new ArrayList<>();
        ArrayList<Pedido> pedidosTotales = new ArrayList<>(getPedidosTotales());
        ArrayList<Pedido> pedidosAsignados = new ArrayList<>(getPedidosAsignados());
        boolean encontrado = false;
        for (Pedido p1 : pedidosTotales){
            for (Pedido p2 : pedidosAsignados){
                if (p1.getId().equalsIgnoreCase(p2.getId())) encontrado = true;
            }
            if (!encontrado && p1.getEstado()!=3 && p1.getEstado()!=4) resultado.add(p1);
            encontrado = false;
        }
        return resultado;
    }

    //Método que devuelve un array con todos los pedidos de la App:
    public ArrayList<Pedido> getPedidosAsignados() {
        ArrayList<Pedido> resultados = new ArrayList<>();
        for (Trabajador t : trabajadores){
            resultados.addAll(t.getPedidosAsignados());
        }
        return resultados;
    }

    //Método que devuelve un array con todos los pedidos asignados a trabajadores de la App:
    public ArrayList<Pedido> getPedidosTotales() {
        ArrayList<Pedido> resultados = new ArrayList<>();
        for (Cliente c : clientes){
            resultados.addAll(c.getPedidos());
        }
        return resultados;
    }

    //método que cambia un dato de uno de los productos del catálogo:
    public boolean cambiaDatoProductoCatalogo(int op1, int idProducto, String dato) {
        for (Producto p : catalogo){
            if (p.getId() == idProducto){
                switch (op1){
                    case 1: //marca
                        p.setMarca(dato);
                        return true;
                    case 2: //modelo
                        p.setModelo(dato);
                        return true;
                    case 3: //descripcion
                        p.setDescripcion(dato);
                        return true;
                    case 4: //precio
                        try {
                            p.setPrecio(Float.parseFloat(dato));
                        } catch (Exception e){
                            return false;
                        }
                        return true;
                    default: return false;
                }
            }
        }
        return false;
    }

    //método que comprueba si un pedido pendiente existe buscando por su ID:
    public boolean exitePedidoPendientePorId(String id) {
        ArrayList<Pedido> pedidosPendientes = getPedidosClientesSinCancelarEntregar();
        for (Pedido pedido : pedidosPendientes){
            if (pedido.getId().equalsIgnoreCase(id)) return true;
        }
        return false;
    }

    //método que busca un pedido por ID de ese pedido:
    public Pedido buscaPedidoByID(String id) {
        for (Pedido pedido : getPedidosClientesSinCancelarEntregar()){
            if (pedido.getId().equalsIgnoreCase(id)) return pedido;
        }
        return null;
    }

    //método que pinta un arraylist de pedidos pasado por parámetro:
    public String pintaPedidos(ArrayList<Pedido> pedidos) {
        // Ancho de la tabla de pedidos:
        int ancho = 105;
        StringBuilder resultado = new StringBuilder();
        // Encabezado de la tabla:
        resultado.append(String.format(
                "╔%s╗\n" +
                        "║ %-103s ║\n" +
                        "╠%s╣\n",
                "═".repeat(ancho), " PEDIDOS SIN ASIGNAR ", "═".repeat(ancho)
        ));
        if (pedidos.isEmpty()) {
            resultado.append(String.format("║ %-103s ║\n", "No hay pedidos todavía..."));
        } else {
            for (Pedido pedido : pedidos.reversed()) {
                String[] lineasPedido = pedido.toString().split("\n");
                // Primera línea con índice
                resultado.append(String.format("║ %-103s ║\n",
                    (pedidos.indexOf(pedido) + 1) + ".- " + lineasPedido[0]));
                // Resto de líneas del pedido (si las hay)
                for (int i = 1; i < lineasPedido.length; i++) {
                    resultado.append(String.format("║    %-100s ║\n", lineasPedido[i]));
                }
                // Comentario (si existe)
                if (!pedido.getComentario().isEmpty()) {
                    resultado.append(String.format("║    · Comentario: %-103s ║\n", pedido.getComentario()));
                }
            }
        }
        // Pie de la tabla:
        resultado.append(String.format("╚%s╝\n", "═".repeat(ancho)));
        return resultado.toString();
    }

    //método que asigna un pedido a un trabajador pasándole solo las IDs de cada uno:
    public boolean asignaPedidoTrabajador(String idPedido, String idTrabajador) {
        Pedido p = buscaPedidoByID(idPedido);
        Trabajador t = getTrabajadorPorID(idTrabajador);
        if (p != null){
            if (t != null){
                t.getPedidosAsignados().add(buscaPedidoByID(idPedido));
                return true;
            }
        }
        return false;
    }

    //método que busca trabajador por una ID de pedido
    public Trabajador buscaTrabajadorPorIdPedido(String id) {
        for (Trabajador t : trabajadores){
            for (Pedido p : t.getPedidosAsignados()){
                if (p.getId().equalsIgnoreCase(id)) return t;
            }
        }
        return null;
    }

    //método que busca un trabajador por ID
    public Trabajador getTrabajadorPorID(String idTrabajador) {
        for (Trabajador t : trabajadores){
            if (t.getId().equalsIgnoreCase(idTrabajador)) return t;
        }
        return null;
    }

    //método que devuelve el string del estado de un pedido según su número:
    public String devuelveStringEstado(int estado) {
        switch (estado){
            case 1: return "En Preparación";
            case 2: return "Enviado";
            case 3: return "Cancelado";
            case 4: return "Entregado";
        }
        return "";
    }

    //MÉTODOS QUE GUARDAN LOS DISTINTOS OBJETOS:

    public void guardaDatos(File directorio) {
        //Guardo en disco todos los datos del controlador:
        if (!catalogo.isEmpty()){
            Persistencia.guardaProductos(this,directorio);
        }
        if (!clientes.isEmpty()){
            Persistencia.guardaClientes(this,directorio);
        }
        if (!trabajadores.isEmpty()){
            Persistencia.guardaTrabajadores(this,directorio);
        }
        if (!admins.isEmpty()){
            Persistencia.guardaAdministradores(this,directorio);
        }
    }

    public void guardaCliente(Cliente c, File directorio){
        Persistencia.guardaCliente(c, directorio);
    }

    public void guardaProducto(Producto p, File directorio){
        Persistencia.guardaProducto(p, directorio);
    }

    public void guardaTrabajador(Trabajador t, File directorio){
        Persistencia.guardaTrabajador(t, directorio);
    }

    public void guardaAdministrador(Admin a, File directorio){
        Persistencia.guardaAdministrador(a, directorio);
    }

    public void eliminaDataTrabajador(Trabajador t) {
        Persistencia.eliminaDataTrabajador(t);
    }

    public String leeFicheroConfiguracion() {
        return Persistencia.leeFicheroConfiguracion();
    }

    public boolean realizarCopiaSeguridad(File dir, Controlador controlador) {
        return Persistencia.realizarCopiaSeguridad(dir, controlador);
    }

    //Métodos para la fecha de inicio de sesión del properties (dependiendo de su clase):

    public String getUltimoInicioSesion(String id) {
        return Persistencia.getUltimoInicioSesion(id);
    }

    public void grabaInicioSesion(String id) {
        Persistencia.grabaInicioSesion(id);
    }

    //Método para saber si la APP está en modo invitado:
    public boolean esInvitado() {
        return Persistencia.esInvitado();
    }

    public void escribeInicioSesionLog(String nombre, String tipoUser) {
        Persistencia.escribeInicioSesionLog(nombre, tipoUser);
    }

    public void escribeCierreSesionLog(String nombre, String tipoUser) {
        Persistencia.escribeCierreSesionLog(nombre, tipoUser);
    }

    public void escribeNuevoPedidoLog(String idClie, String idTrab) {
        Persistencia.escribeNuevoPedidoLog(idClie,idTrab);
    }

    public void escribeActualizacionPedidoLog(String idPedido, String estado) {
        Persistencia.escribeActualizacionPedidoLog(idPedido,estado);
    }

    public void escribeArchivoExcel() {
        Persistencia.escribeArchivoExcel(getPedidosTotales());
    }

    public void escribeArchivoPdf(Pedido pedido) {
        Persistencia.escribeArchivoPdf(pedido);
    }

    public String getRutaExcel() {
        return Persistencia.iniciaProperties().getProperty("RUTA_EXCEL");
    }

    public String getRutaPdf() {
        return Persistencia.iniciaProperties().getProperty("RUTA_PDF");
    }
}
