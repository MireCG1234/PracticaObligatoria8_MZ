package models;

import controlador.Controlador;

import java.io.Serializable;

public class Admin implements Serializable {

    //ATRIBUTOS
    private String id;
    private String nombre;
    private String clave;
    private String email;

    //CONSTRUCTORES

    public Admin(String nombre, String clave, String email, Controlador controlador) {
        id = controlador.devuelveIdAdmin();
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
    }


    //GETTERS Y SETTERS
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    //OTROS MÉTODOS
    //método que verifica email y contraseña para hacer login de Administrador.
    public boolean login(String email, String clave){
        return email.equals(this.email) && clave.equals(this.clave);
    }
}
