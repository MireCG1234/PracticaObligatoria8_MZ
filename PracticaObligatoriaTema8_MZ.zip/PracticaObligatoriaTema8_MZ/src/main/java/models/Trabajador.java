package models;

import controlador.Controlador;
import utils.Utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class Trabajador implements Serializable {

    //ATRIBUTOS
    private String id;
    private String nombre;
    private String clave;
    private String email;
    private int movil;
    private String idTelegram;
    private ArrayList<Pedido> pedidosAsignados;

    //CONSTRUCTORES

    public Trabajador(String nombre, String clave, String email, int movil, Controlador controlador) {
        id = controlador.devuelveIdTrabajador();
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
        this.movil = movil;
        idTelegram = "";
        pedidosAsignados = new ArrayList<>();
    }

    public Trabajador(Trabajador trabajador) {
        id = trabajador.id;
        nombre = trabajador.nombre;
        clave = trabajador.clave;
        email = trabajador.email;
        movil = trabajador.movil;
        idTelegram = "";
        pedidosAsignados = new ArrayList<>();
        pedidosAsignados.addAll(trabajador.getPedidosAsignados());
    }


    //GETTERS Y SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getMovil() {
        return movil;
    }

    public void setMovil(int movil) {
        this.movil = movil;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Pedido> getPedidosAsignados() {
        return pedidosAsignados;
    }

    public void setPedidosAsignados(ArrayList<Pedido> pedidosAsignados) {
        this.pedidosAsignados = pedidosAsignados;
    }

    public String getIdTelegram() {
        return idTelegram;
    }

    public void setIdTelegram(String idTelegram) {
        this.idTelegram = idTelegram;
    }

    //OTROS MÉTODOS
    //método que verifica email y contraseña para hacer login de Trabajador.
    public boolean login(String email, String clave){
        return email.equals(this.email) && clave.equals(this.clave);
    }

    //método que signa un pedido:
    public boolean asignaPedido(Pedido p){
        return false;
    }

    //método que busca un pedido por ID de ese pedido:
    public Pedido buscaPedidoByID(String id) {
        for (Pedido pedido : pedidosAsignados){
            if (pedido.getId().equalsIgnoreCase(id)) return pedido;
        }
        return null;
    }

    //método que devuelve el número de pedidos pendientes (Que no estén entregados, es decir, distinto de 4):
    public int numPedidosPendientes(){
        int numPedidos = 0;
        if (pedidosAsignados == null) return numPedidos;
        for (Pedido p : pedidosAsignados){
            if (p.getEstado()!=4 && p.getEstado()!=3) numPedidos++;
        }
        return numPedidos;
    }

    //muestra toda la información del cliente
    public String pintaDatosTrabajador() {
        return  " ╔═════════════════════════════════════════╗\n" +
                "\t INFORMACIÓN DE " + nombre.toUpperCase() + "   \n" +
                " ╠═════════════════════════════════════════╣\n" +
                "   · Email:  \t\t" + email + "\n" +
                "   · Clave:  \t\t" + Utils.claveAsteriscos(clave) + "\n" +
                "   · Teléfono:  \t" + movil + "\n" +
                "   · ID Telegram:  \t" + idTelegram + "\n" +
                " ╚═════════════════════════════════════════╝\n";
    }

    //Muestra todos los pedidos que tiene asignados el trabajador:
    public String pintaPedidosAsignados(Controlador controlador) {
        PedidoClienteDataClass temp;
        StringBuilder sb = new StringBuilder();
        sb.append("\n ╔════════════════════════════════════════════════════════════╗\n")
                .append("                     PEDIDOS DEL TRABAJADOR\n")
                .append(" ╠════════════════════════════════════════════════════════════╣\n");

        if (pedidosAsignados.isEmpty() || getPedidosCanceladosEntregados().size() == pedidosAsignados.size()) {
            sb.append("                  · NO HAY PEDIDOS ASIGNADOS · \n");
        } else {
            int index = 1;
            sb.append("\n");
            for (Pedido pedido : pedidosAsignados) {
                if (pedido.getEstado() != 3 && pedido.getEstado() != 4){
                    temp = new PedidoClienteDataClass(controlador.getClientePorIdPedido(pedido.getId()),pedido);
                    sb.append(String.format("    %d. - Id: %s (%d productos) \n" +
                                    "       - Estado: %s \n" +
                                    "       - Fecha Pedido: %s \n" +
                                    "       - Nombre: %s \n" +
                                    "       - Teléfono: %d \n" +
                                    "       - Dirección: %s \n" +
                                    "       - Localidad: %s \n" +
                                    "       - Provincia: %s \n",
                            index++,
                            pedido.getId(),
                            pedido.getProductos().size(),
                            pedido.pintaEstado(pedido.getEstado()),
                            Utils.formatearFecha(pedido.getFechaPedido()),
                            temp.getCliente().getNombre(),
                            temp.getCliente().getMovil(),
                            temp.getCliente().getDireccion(),
                            temp.getCliente().getLocalidad(),
                            temp.getCliente().getProvincia()));
                    //añadimos el comentario si es que tiene:
                    if (!temp.getPedido().getComentario().isEmpty()) sb.append("       - Comentario: " +
                            temp.getPedido().getComentario() + "\n\n");
                    else sb.append("\n");
                }
            }
        }
        sb.append(" ╚════════════════════════════════════════════════════════════╝\n");
        return sb.toString();
    }

    private ArrayList<Pedido> getPedidosCanceladosEntregados() {
        ArrayList<Pedido> pedidosCanceladosEntregados = new ArrayList<>();
        for (Pedido p : pedidosAsignados){
            if (p.getEstado() == 4 || p.getEstado() == 3) pedidosCanceladosEntregados.add(p);
        }
        return pedidosCanceladosEntregados;
    }

    public String getPedidosTerminados(Controlador controlador) {
        ArrayList<Pedido> pedidosCanceladosEntregados = getPedidosCanceladosEntregados();
        PedidoClienteDataClass temp;
        StringBuilder sb = new StringBuilder();
        sb.append("\n ╔════════════════════════════════════════════════════════════╗\n")
          .append("                 PEDIDOS TERMINADOS DEL TRABAJADOR\n")
                .append(" ╠════════════════════════════════════════════════════════════╣\n");

        if (pedidosCanceladosEntregados.isEmpty()) {
            sb.append("                    · NO HAY PEDIDOS TERMINADOS · \n");
        } else {
            int index = 1;
            sb.append("\n");
            for (Pedido pedido : pedidosCanceladosEntregados) {
                temp = new PedidoClienteDataClass(controlador.getClientePorIdPedido(pedido.getId()),pedido);
                sb.append(String.format("    %d. - Id: %s (%d productos) \n" +
                                "       - Estado: %s \n" +
                                "       - Fecha Pedido: %s \n" +
                                "       - Nombre: %s \n" +
                                "       - Teléfono: %d \n" +
                                "       - Dirección: %s \n" +
                                "       - Localidad: %s \n" +
                                "       - Provincia: %s \n\n",
                        index++,
                        pedido.getId(),
                        pedido.getProductos().size(),
                        pedido.pintaEstado(pedido.getEstado()),
                        Utils.formatearFecha(pedido.getFechaPedido()),
                        temp.getCliente().getNombre(),
                        temp.getCliente().getMovil(),
                        temp.getCliente().getDireccion(),
                        temp.getCliente().getLocalidad(),
                        temp.getCliente().getProvincia()));
            }
        }
        sb.append(" ╚════════════════════════════════════════════════════════════╝\n");
        return sb.toString();
    }
}
