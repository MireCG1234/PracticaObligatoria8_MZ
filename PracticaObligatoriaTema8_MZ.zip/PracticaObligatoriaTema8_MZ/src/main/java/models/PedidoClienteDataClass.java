package models;

import java.io.Serializable;

public class PedidoClienteDataClass implements Serializable {

    private Cliente cliente;
    private Pedido pedido;

    public PedidoClienteDataClass(Cliente cliente, Pedido pedido) {
        this.cliente = cliente;
        this.pedido = pedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }


}
