package models;

import controlador.Controlador;
import utils.Utils;

import java.io.Serializable;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Comparator;

import static data.DataProductos.IVA;

public class Cliente implements Serializable {

    //ATRIBUTOS
    private String id;
    private String email;
    private String clave;
    private String nombre;
    private String localidad;
    private String provincia;
    private String direccion;
    private int movil;
    private ArrayList<Pedido> pedidos;
    private ArrayList<Producto> carro;

    //CONSTRUCTORES

    public Cliente(String email, String clave, String nombre, String localidad, String provincia,
                    String direccion, int movil, Controlador controlador) {
        id = controlador.devuelveIdCliente();
        this.email = email;
        this.clave = clave;
        this.nombre = nombre;
        this.localidad = localidad;
        this.provincia = provincia;
        this.direccion = direccion;
        this.movil = movil;
        pedidos = new ArrayList<>();
        carro = new ArrayList<>();
    }

    public Cliente(Cliente cliente) {
        id = cliente.id;
        email = cliente.email;
        clave = cliente.clave;
        nombre = cliente.nombre;
        localidad = cliente.localidad;
        provincia = cliente.provincia;
        direccion = cliente.direccion;
        movil = cliente.movil;
        pedidos = cliente.pedidos;
        carro = cliente.carro;
    }

    //GETTERS Y SETTERS
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getMovil() {
        return movil;
    }

    public void setMovil(int movil) {
        this.movil = movil;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public ArrayList<Producto> getCarro() {
        return carro;
    }

    public void setCarro(ArrayList<Producto> carro) {
        this.carro = carro;
    }


    //OTROS MÉTODOS
    //método que verifica email y contraseña para hacer login de Cliente.
    public boolean login(String email, String clave){
        return email.equals(this.email) && clave.equals(this.clave);
    }

    public void addProductoCarro(Producto p){
        carro.add(p);
    }

    public boolean quitaProductoCarro(int idProducto){
        for (Producto p : carro){
            if (p.getId() == idProducto) carro.remove(p);
            return true;
        }
        return false;
    }

    public int numProductosCarro(){
        return carro.size();
    }

    public void vaciaCarro(){
        carro.clear();
    }

    public void addPedido(Pedido p){
        pedidos.add(p);
    }

    public float precioCarroSinIVA(int iva){
        float resultado = 0f;
        for (Producto p : carro){
            resultado += p.getPrecio();
        }
        return resultado;
    }

    public float precioIvaCarro(int iva){
        float resultado = 0f;
        for (Producto p : carro){
            resultado += IVA * p.getPrecio();
        }
        return resultado;
    }

    public float precioCarroConIVA(int iva){
        float resultado = 0f;
        for (Producto p : carro){
            resultado += ((IVA * p.getPrecio()) + p.getPrecio());
        }
        return resultado;
    }

    public boolean existeProductoCarro(int idProducto){
        for (Producto p : carro) {
            if (p.getId() == idProducto) return true;
        }
        return false;
    }

    //Método para contar los pedidos que tiene sin entregar:
    public int cuentaPedidosSinEntregar(){
        int contador = 0;
        if (pedidos.isEmpty()) return contador;
        for (Pedido p : pedidos){
            //El 4 es el pedido ya ENTREGADO y el 3 es el pedido CANCELADO
            if (p.getEstado() != 4 && p.getEstado() != 3) contador++;
        }
        return contador;
    }

    //muestra toda la información del cliente
    public String pintaDatosCliente() {
        return "\n ╔══════════════════════════════════════════════════════════╗\n" +
                "\t\t\t\t INFORMACIÓN DE " + nombre.toUpperCase() + "\n"+
                " ╠══════════════════════════════════════════════════════════╣\n" +
                "   · Email:  \t\t" + email + "\n" +
                "   · Clave:  \t\t" + Utils.claveAsteriscos(clave) + "\n" +
                "   · Dirección:  \t" + direccion + "\n" +
                "   · Localidad:  \t" + localidad + "\n" +
                "   · Provincia:  \t" + provincia + "\n" +
                "   · Teléfono:  \t" + movil + "\n" +
                " ╚══════════════════════════════════════════════════════════╝\n";
    }

    public String pintaPedidosCliente(Controlador controlador) {
        // Listas auxiliares para Cancelados y Entregados:
        ArrayList<Pedido> pedidosCancelados = new ArrayList<>(ordenaPorFechaReciente(getPedidosCancelados()));
        ArrayList<Pedido> pedidosEntregados = new ArrayList<>(ordenaPorFechaReciente(getPedidosEntregados(controlador)));

        // Ancho de la tabla de pedidos:
        int ancho = 105;
        StringBuilder resultado = new StringBuilder();

        // Encabezado de la tabla:
        resultado.append(String.format(
                "╔%s╗\n" +
                        "║ %-103s ║\n" +
                        "╠%s╣\n",
                "═".repeat(ancho), "Pedidos de " + nombre, "═".repeat(ancho)
        ));

        if (pedidos.isEmpty() || !hayPedidosPreparados()) {
            resultado.append(String.format("║ %-103s ║\n", "No hay pedidos todavía..."));
        } else {
            for (Pedido pedido : pedidos.reversed()) {
                if (pedido.getEstado() != 3 && pedido.getEstado() != 4) {
                    String[] lineasPedido = pedido.toString().split("\n");

                    // Primera línea con índice
                    resultado.append(String.format("║ %-103s ║\n",
                            (pedidos.indexOf(pedido) + 1) + ".- " + lineasPedido[0]));

                    // Resto de líneas del pedido (si las hay)
                    for (int i = 1; i < lineasPedido.length; i++) {
                        resultado.append(String.format("║    %-100s ║\n", lineasPedido[i]));
                    }

                    // Comentario (si existe)
                    if (!pedido.getComentario().isEmpty()) {
                        resultado.append(String.format("║    · Comentario: %-86s ║\n", pedido.getComentario()));
                    }
                }
            }
        }

        // Sección de PEDIDOS CANCELADOS:
        resultado.append(String.format(
                "╠%s╣\n" +
                        "║ %-103s ║\n" +
                        "╠%s╣\n",
                "═".repeat(ancho), "- PEDIDOS CANCELADOS", "═".repeat(ancho)
        ));

        if (pedidosCancelados.isEmpty()) {
            resultado.append(String.format("║ %-103s ║\n", "No hay pedidos cancelados todavía..."));
        } else {
            for (Pedido pedido : pedidosCancelados) {
                String[] lineasPedido = pedido.toString().split("\n");

                resultado.append(String.format("║ %-103s ║\n",
                        (pedidos.indexOf(pedido) + 1) + ".- " + lineasPedido[0]));

                for (int i = 1; i < lineasPedido.length; i++) {
                    resultado.append(String.format("║    %-100s ║\n", lineasPedido[i]));
                }

                if (!pedido.getComentario().isEmpty()) {
                    resultado.append(String.format("║    · Comentario: %-86s ║\n", pedido.getComentario()));
                }
            }
        }

        // Sección de PEDIDOS ENTREGADOS:
        resultado.append(String.format(
                "╠%s╣\n" +
                        "║ %-103s ║\n" +
                        "╠%s╣\n",
                "═".repeat(ancho), "- PEDIDOS ENTREGADOS", "═".repeat(ancho)
        ));

        if (pedidosEntregados.isEmpty()) {
            resultado.append(String.format("║ %-103s ║\n", "No hay pedidos entregados todavía..."));
        } else {
            for (Pedido pedido : pedidosEntregados) {
                String[] lineasPedido = pedido.toString().split("\n");

                resultado.append(String.format("║ %-103s ║\n",
                        (pedidos.indexOf(pedido) + 1) + ".- " + lineasPedido[0]));

                for (int i = 1; i < lineasPedido.length; i++) {
                    resultado.append(String.format("║    %-100s ║\n", lineasPedido[i]));
                }

                if (!pedido.getComentario().isEmpty()) {
                    resultado.append(String.format("║    · Comentario: %-86s ║\n", pedido.getComentario()));
                }
            }
        }

        // Pie de la tabla:
        resultado.append(String.format("╚%s╝\n", "═".repeat(ancho)));

        return resultado.toString();
    }

    private ArrayList<Pedido> ordenaPorFechaReciente(ArrayList<Pedido> pedidos) {
        //pedidosCancelados.sort((p1, p2) -> p2.getFechaPedido().isAfter(p1.getFechaPedido()) ? 1 : (p2.getFechaPedido().isBefore(p1.getFechaPedido()) ? -1 : 0));
        pedidos.sort((p1, p2) -> p2.getFechaPedido().compareTo(p1.getFechaPedido()));
        return pedidos;
    }

    //método para averiguar si existen pedidos que no estén cancelados ni entregados (Para el pintaPedidos):
    private boolean hayPedidosPreparados() {
        for (Pedido p : pedidos){
            if (p.getEstado() != 3 && p.getEstado() != 4) return true;
        }
        return false;
    }


    private ArrayList<Pedido> getPedidosCancelados() {
        ArrayList<Pedido> temp = new ArrayList<>();
        for (Pedido p : pedidos){
            if (p.getEstado() == 3) temp.add(p);
        }
        return temp;
    }

    private ArrayList<Pedido> getPedidosEntregados(Controlador controlador) {
        ArrayList<Pedido> temp = new ArrayList<>();
        for (Pedido p : pedidos){
            if (p.getEstado() == 4) temp.add(p);
        }
        return temp;
    }


    public String pintaCarro() {
        String resultado = String.format("╔%s╗\n", "═".repeat(80));
        resultado += String.format("║%-80s║\n", "                             PRODUCTOS DEL CARRITO");
        resultado += String.format("╠%s╣\n", "═".repeat(80));
        if (carro.isEmpty()) resultado += String.format("║%-80s║\n", "                            No hay productos aún ...");
        for (int i = 0; i < carro.size(); i++) {
            Producto p = carro.get(i);
            resultado += String.format("%s\n", p.toString());

            if (!p.getDescripcion().isEmpty()) {
                resultado += String.format("       · Descripción: %s\n", p.getDescripcion());
            }

            if (i != carro.size() - 1) {
                resultado += String.format("╠%s╣\n", "═".repeat(80));
            }
        }
        resultado += String.format("╠%s╣\n", "═".repeat(80));
        resultado += String.format("║%79s ║\n", String.format("Total del Carrito: %.2f E", calculaPrecioTotalCarrito()));
        resultado += String.format("╚%s╝\n", "═".repeat(80));

        return resultado;
    }

    private float calculaPrecioTotalCarrito() {
        float precioTotal = 0;
        for (Producto p : carro){
            precioTotal += p.getPrecio();
        }
        return precioTotal;
    }


}
