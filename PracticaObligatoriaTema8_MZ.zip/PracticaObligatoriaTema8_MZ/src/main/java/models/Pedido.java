package models;

import controlador.Controlador;
import utils.Utils;

import javax.naming.ldap.Control;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static data.DataProductos.IVA;

public class Pedido implements Serializable {

    //ATRIBUTOS
    private String id;
    private LocalDateTime fechaPedido;
    private LocalDateTime fechaEstimada;
    private int estado;
    private String comentario;
    private ArrayList<Producto> productos;


    //CONSTRUCTORES
    public Pedido(String id, LocalDateTime fechaPedido, LocalDateTime fechaEstimada, int estado, String comentario, ArrayList<Producto> productos) {
        this.id = id;
        this.fechaPedido = fechaPedido;
        this.fechaEstimada = calculaFechaEstimada(fechaPedido);
        this.estado = estado;
        this.comentario = comentario;
        this.productos = new ArrayList<>();
        this.productos.addAll(productos);
    }

    public Pedido(LocalDateTime fechaPedido, LocalDateTime fechaEstimada, String comentario, ArrayList<Producto> productos, Controlador controlador) {
        id = controlador.devuelveIdPedido();
        this.fechaPedido = fechaPedido;
        this.fechaEstimada = calculaFechaEstimada(fechaPedido);
        estado = 1;
        this.comentario = comentario;
        this.productos.addAll(productos);
    }

    public Pedido(ArrayList<Producto> productos, Controlador controlador) {
        id = controlador.devuelveIdPedido();
        fechaPedido = LocalDateTime.now();
        fechaEstimada = calculaFechaEstimada(fechaPedido);
        estado = 1;
        comentario = "";
        this.productos = new ArrayList<>();
        this.productos.addAll(productos);
    }

    public Pedido(Pedido pedido) {
        id = pedido.id;
        fechaPedido = pedido.fechaPedido;
        fechaEstimada = pedido.fechaEstimada;
        estado = pedido.estado;
        comentario = pedido.comentario;
        productos = new ArrayList<>();
        productos.addAll(pedido.getProductos());
    }

    //GETTERS Y SETTERS
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDateTime getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(LocalDateTime fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public LocalDateTime getFechaEstimada() {
        return fechaEstimada;
    }

    public void setFechaEstimada(LocalDateTime fechaEstimada) {
        this.fechaEstimada = fechaEstimada;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }


    //OTROS MÉTODOS

    //metodo para calcular la fecha estimada
    public LocalDateTime calculaFechaEstimada(LocalDateTime fechaPedido){
        return fechaPedido.plusDays(5);
    }


    public boolean cambiaEstado(int nuevoEstado){
        if (nuevoEstado > 0 && nuevoEstado < 5){
            estado = nuevoEstado;
            return true;
        }
        else return false;
    }

    public boolean cambiaFechaEntrega(LocalDateTime nuevaFecha){
        if (nuevaFecha.isAfter(fechaPedido)) fechaEstimada = nuevaFecha;
        return false;
    }

    public float calculaTotalPedidoSinIVA(){
        float resultado = 0f;
        if (productos.isEmpty()) return resultado;
        for (Producto p : productos){
            resultado += p.getPrecio();
        }
        return resultado;
    }
    // A estos métodos les quité el parámetro del IVA porque lo tenemos estático y final en DataProductos.
    public float calculaIvaPedido(){
        float resultado = 0f;
        if (productos.isEmpty()) return resultado;
        for (Producto p : productos){
            resultado += (IVA * p.getPrecio());
        }
        return resultado;
    }

    public float calculaTotalPedidoConIVA(){
        float resultado = 0f;
        if (productos.isEmpty()) return resultado;
        for (Producto p : productos){
            resultado += ((IVA * p.getPrecio()) + p.getPrecio());
        }
        return resultado;
    }

    public int numArticulos(){
        return productos.size();
    }

    /* ESTE MÉTODO NO SE USA
    public Producto buscaProducto(int idProducto){

    }*/

    /* ESTE MÉTODO NO SE USA
    public void addProducto(Producto producto){

    }*/

    //metodo para pintar toda la información sobre un pedido:
    public String pintaPedido(Pedido pedido, Cliente cliente) {
        return "\n ╔═════════════════════════════════════════════════════════╗\n" +
                "               PEDIDO " + pedido.getId() + "\n" +
                " ╠═════════════════════════════════════════════════════════╣\n" +
                "   · Estado:  \t\t\t" + estado + "\n" +
                "   · Cliente:  \t\t\t" + cliente.getNombre() + "\n" +
                "   · Dirección:  \t\t" + cliente.getDireccion() + "\n" +
                "   · Localidad:  \t\t" + cliente.getLocalidad() + "\n" +
                "   · Provincia:  \t\t" + cliente.getProvincia() + "\n" +
                "   · Teléfono:  \t\t" + cliente.getMovil() + "\n" +
                "   · Correo:  \t\t\t" + cliente.getEmail() + "\n" +
                "   · Fecha Pedido:  \t\t" + formatearFecha(fechaPedido) + "\n" +
                "   · Entrega Estimada:  \t" + formatearFecha(fechaEstimada) + "\n" +
                "   · Comentarios:  \t\t" + comentario + "\n" +
                "   · Detalles: \n" +
                " ╠═════════════════════════════════════════════════════════╣\n" +
                "   · TOTAL DEL PEDIDO:  \t\t\t" + precioArreglado(calculaTotalPedido(pedido)) + "E \n" +
                " ╚═════════════════════════════════════════════════════════╝\n";
    }

    //metodo que formatea una fecha a dd-mm-yyyy:
    public static String formatearFecha(LocalDateTime fecha) {
        //define el formato deseado
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //devuelve la fecha en el formato especificado
        return fecha.format(formato);
    }

    //metodo que calcula el precio total de un pedido (calculando los precios de los productos con sus cantidades)
    public static float calculaTotalPedido(Pedido pedido){
        float precioFinal = 0f;
        for (Producto p : pedido.getProductos()){
            //No se multiplica por la cantidad de veces que lo has añadido porque está duplicado en la lista:
            precioFinal += p.getPrecio();
        }
        return precioFinal;
    }

    //metodo que arregla el precio en cuanto a formato:
    public static String precioArreglado(float precio) {
        return String.format("%.2f", precio);
    }

    //método que pinta el estado de un pedido:
    public String pintaEstado(int estado) {
        return switch (estado) {
            case 1 -> "En Preparación";
            case 2 -> "Enviado";
            case 3 -> "Cancelado";
            case 4 -> "Entregado";
            default -> "";
        };
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id)
                .append(" (").append(productos.size()).append(" Productos) | Estado = ")
                .append(pintaEstado(estado))
                .append(" | FP: ").append(Utils.formatearFecha(fechaPedido))
                .append(", FE: ").append(Utils.formatearFecha(fechaEstimada))
                .append("\n");

        productos.forEach(producto ->
                sb.append("  - Nombre: ").append(producto.getMarca())
                        .append(" | Precio: ").append(producto.getPrecio()).append("E\n")
        );

        return sb.toString();
    }
}
