package comunicaciones;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import controlador.Controlador;
import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import models.Cliente;
import models.Pedido;
import models.Producto;
import utils.Utils;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import static jakarta.mail.Transport.send;

public class Comunicaciones {

    private static final String host = "smtp.gmail.com";
    private static final String user = "fernanshopmz@gmail.com";
    private static final String pass = "pfqj nhhl oeah iuyf";

    public static boolean enviarMensaje(String destino,String asunto, String mensaje){
        // Aquí puedes construir tu contenido HTML
        String contenidoHTML = mensaje;

        Properties props = new Properties();
        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.host",host);
        props.put("mail.smtp.socketFactory.port","465");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(props, new Authenticator(){
            @Override
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(user,pass);
            }
        });

        try{
            Message message = new MimeMessage(session);
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(destino));
            message.setSubject(asunto);

            // Establecer el contenido como HTML
            message.setContent(contenidoHTML, "text/html");

            send(message);
        } catch (Exception e){
            throw new RuntimeException(e);
        }
        return true;
    }

    public static void generaPdf(Pedido pedido, Controlador controlador){
        Document document = new Document();

        try {
            PdfWriter writer = PdfWriter.getInstance(document,
                    new FileOutputStream(controlador.getRutaPdf() + pedido.getId() + ".pdf"));
            document.open();

            PdfContentByte cb = writer.getDirectContent();
            Graphics g = cb.createGraphicsShapes(PageSize.LETTER.getWidth(), PageSize.LETTER.getHeight());

            //--------------------- pagina 1 --------------------------
            g.setColor(Color.ORANGE);
            g.drawLine(-100, 10, 1000, 10);
            Font font1 = new Font("Tahoma", Font.BOLD, 30);
            g.setFont(font1);
            g.drawString("Detalles del pedido " + pedido.getId(), 40, 60);

            Font font2 = new Font("Tahoma", Font.PLAIN, 15);
            g.setFont(font2);
            g.setColor(Color.BLACK);
            g.drawString("Fecha del Pedido: " + Utils.formatearFecha(pedido.getFechaPedido()), 45, 100);
            g.drawString("Fecha Estimada de Entrega: " + Utils.formatearFecha(pedido.getFechaEstimada()), 45, 130);
            g.drawString("Estado: " + Utils.devuelveStringEstado(pedido.getEstado()), 45, 160);
            g.drawString("Comentario:  " + ((pedido.getComentario().isEmpty()) ? "-" : pedido.getComentario()), 45, 190);
            g.drawString("Productos del Pedido: ", 45, 220);

            int contador = 1;
            int altura = 250;
            int sumatorio = 0;
            for (Producto p : pedido.getProductos()) {
                g.drawString("      " + contador + ".- " + p.getModelo() + " - " + p.getMarca() + "   |    " + p.getPrecio() + " €", 55, altura);
                contador++;
                altura += 30;
                sumatorio += p.getPrecio();
            }

            g.setColor(Color.RED);
            Font font5 = new Font("Tahoma", Font.BOLD, 20);
            g.setFont(font5);
            g.drawOval(430, 330, 110, 60);
            g.drawString("Total del pedido: " + sumatorio + " €", 280, 370);

            Cliente cTemp = controlador.getClientePorIdPedido(pedido.getId());

            g.setColor(Color.BLACK);
            Font font3 = new Font("Tahoma", Font.BOLD, 30);
            g.setFont(font3);
            g.drawLine(-100, 410, 1000, 410);
            g.drawString("Detalles del CLiente " + cTemp.getId(), 40, 470);

            g.setFont(font2);
            g.drawString("ID del Cliente: " + cTemp.getId(), 45, 510);
            g.drawString("Nombre del Cliente: " + cTemp.getNombre(), 45, 540);
            g.drawString("Correo: " + cTemp.getEmail(), 45, 570);
            g.drawString("Destino: " + cTemp.getDireccion() + ", " + cTemp.getLocalidad() + " - " + cTemp.getProvincia(), 45, 600);
            g.drawString("Teléfono de contacto: " + cTemp.getMovil(), 45, 630);

            g.setColor(Color.GRAY);
            Font font4 = new Font("Tahoma", Font.PLAIN, 13);
            g.setFont(font4);
            g.drawString("FernanShopMZ©. Todos los derechos reservados. Abril-2025", 200, 730);
            g.drawString("Extracto del Pedido a FernanShopMZ - Para más detalles Accede a nuestra APP", 100, 760);
            g.drawLine(-100, 700, 1000, 700);

            // ✅ Muy importante: cerrar el objeto Graphics
            g.dispose();

        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        } finally {
            // ✅ Cerrar el documento en finally por seguridad
            if (document.isOpen()) {
                document.close();
            }
        }
    }


    public static void enviaPdf(String destinatario, String asunto, String cuerpo, String rutaAdjunto){
        final String remitente = "fernanshopmz.oficial@gmail.com";
        final String clave = "asal spwq unan pxtu"; // Usa tokens si usas Gmail

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, clave);
            }
        });

        try {
            Message mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(remitente));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensaje.setSubject(asunto);

            // Cuerpo del mensaje
            MimeBodyPart textoParte = new MimeBodyPart();
            textoParte.setContent(cuerpo, "text/html; charset=utf-8");

            // Archivo adjunto
            MimeBodyPart adjuntoParte = new MimeBodyPart();
            DataSource source = new FileDataSource(rutaAdjunto);
            adjuntoParte.setDataHandler(new DataHandler(source));
            adjuntoParte.setFileName(source.getName());

            // Crear multipart y agregar ambas partes
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(textoParte);
            multipart.addBodyPart(adjuntoParte);

            mensaje.setContent(multipart);

            Transport.send(mensaje);
            System.out.println("Correo enviado con adjunto exitosamente.");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public static boolean enviarCSV(String destinatario, String rutaExcel){

        String remitente = "mireyacuegarri@gmail.com";
        String asunto = "Reporte Automático Pedidos CSV - FernanShopMZ";
        String cuerpoHtml = "<h3>Buenos días :3 ,</h3><p>Le enviamos el último reporte en formato CSV adjunto.</p>";

        Properties props = new Properties();
        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.host",host);
        props.put("mail.smtp.socketFactory.port","465");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(props, new Authenticator(){
            @Override
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(user,pass);
            }
        });

        try{
            // Crear mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);

            // Crear cuerpo HTML
            MimeBodyPart cuerpo = new MimeBodyPart();
            cuerpo.setContent(cuerpoHtml, "text/html; charset=utf-8");

            // Adjuntar archivo CSV
            MimeBodyPart adjunto = new MimeBodyPart();
            String rutaCSV = rutaExcel;  // Cambia esta ruta a la tuya
            DataSource source = new FileDataSource(rutaCSV);
            adjunto.setDataHandler(new DataHandler(source));
            adjunto.setFileName("Reporte_Pedidos_FernanShopMZ.csv");

            // Juntar partes
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(cuerpo);
            multipart.addBodyPart(adjunto);

            // Asignar contenido al mensaje
            message.setContent(multipart);

            // Enviar
            Transport.send(message);

            System.out.println("Correo enviado correctamente con el CSV adjunto.");
        } catch (Exception e){
            throw new RuntimeException(e);
        }
        return true;
    }


    //MENSAJES PREDETERMINADOS PARA MANDAR POR TELEGRAM AL CLIENTE Y AL TRABAJADOR:
    public static String mensajePredeterminado(){
        return  "¡Bienvenido/a al Chat Bot de FernanShop!";
    }

    public static String mensajeInformaEstadoPedido(String idPedido, String estado){
        return  "Su pedido con ID: " + idPedido + " ha sido modificado al estado de " + estado + ".";
    }

    public static String mensajeNuevoPedidoTrabajador(String idPedido, String estado){
        return  "Tiene un nuevo pedido asignado con ID: " + idPedido + ", y estado: " + estado + ".";
    }

    public static String mensajeTrabajadorDadoAlta(String idTrabajador){
        return  "El trabajador con ID: " + idTrabajador + " ha sido dado de alta satisfactoriamente. - FernanShopMZ";
    }

    public static String mensajeTrabajadorDadoBaja(String idTrabajador){
        return  "El trabajador con ID: " + idTrabajador + " ha sido dado de baja. Lo sentimos. - FernanShopMZ";
    }

    public static String mensajeDatosModificados(){
        return  "Los datos de su perfil han sido modificados con éxito. Consulte su nuevo perfil en la aplicación de FernanShop.";
    }


    // para usarlo en el main: Utils.Comunicaciones.enviaMensajeTelegram("asd", idChatTelegramCliente);
    public static boolean enviaMensajeTelegram(String mensaje, String idChatCliente){
        String direccion;
        String fijo = "https://api.telegram.org/bot7982023086:AAFaw7kux46l-0_YgoLrI1eZkIRxbvbJcTw/sendMessage?chat_id=" + idChatCliente + "&text=";
        direccion = fijo + mensaje;
        URL url;
        boolean dev;
        dev = false;
        try{
            url = new URL(direccion);
            URLConnection con = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            dev = true;
        } catch (Exception e){
            System.out.println("    · No se ha podido mandar el mensaje a ese ID de Telegram.");
        }
        return dev;
    }



}
