package view;

import comunicaciones.Comunicaciones;
import controlador.Controlador;
import data.DataProductos;
import models.*;
import persistencia.Persistencia;
import utils.Email;
import utils.Menus;
import utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import static comunicaciones.Comunicaciones.enviaPdf;
import static comunicaciones.Comunicaciones.generaPdf;
import static persistencia.Persistencia.iniciaProperties;
import static utils.Utils.generaNumeroValidacion;
import static utils.Utils.validarEmail;

public class Main {
    //CONSTANTES
    public static final Scanner S = new Scanner(System.in);

    //MAIN
    public static void main(String[] args) {
        //Objeto Controlador que controlará las acciones del programa:
        Controlador controlador = new Controlador();

        //Menú Inicial del programa:
        do {
            Menus.logo(); //pinta el logo de la tienda
            System.out.println("""
                    ╔═══════════════════════════════════════════════════╗
                    ║          BIENVENIDOS A NUESTRA TIENDA :)          ║
                    ╚═══════════════════════════════════════════════════╝
                    ============  ¿En qué podemos ayudarle?  ============
                    """);
            Object user = menuInicio(controlador);
            if (user != null) {
                menuUsuario(controlador, user);
            }
        } while (true);
    }

    //Menú del Usuario:
    private static void menuUsuario(Controlador controlador, Object user) {
        if (user instanceof Admin) menuAdmin(controlador,user);
        if (user instanceof Trabajador) menuTrabajador(controlador,user);
        if (user instanceof Cliente) menuCliente(controlador,user);
    }

                                                                                     //FUNCIONES ADMINISTRADOR:
    //Menú del Administrador:
    private static void menuAdmin(Controlador controlador, Object user) {
        String op = "";
        do {
            System.out.println();
            //Escribo el inicio de sesión en el archivo log:
            controlador.escribeInicioSesionLog(((Admin) user).getNombre(), "Administrador");
            //Doy la bienvenida al usuario:
            System.out.printf("¡Bienvenido Administrador!. %s \n", (!controlador.getPedidosSinAsignar().isEmpty()) ? "Tienes " +
                    controlador.getPedidosSinAsignar().size() + " pedidos por asignar." : "No tienes pedidos por asignar.");

            //Enseño por pantalla la linea del último inicio de sesión (si el usuario tiene):
            if (!controlador.getUltimoInicioSesion(((Admin) user).getId()).equalsIgnoreCase("")) {
                System.out.println("Usted inició sesión por última vez el " + controlador.getUltimoInicioSesion(((Admin) user).getId()) + ".");
            }
            //Llamamos al properties para grabar su inicio de sesión:
            controlador.grabaInicioSesion(((Admin) user).getId());

            Menus.menuAdministradorConsola(); //imprimo el menú del admin.
            System.out.print("Introduce una opción: ");
            op = S.nextLine();
            switch (op) {
                case "1": //Ver el catálogo.
                    System.out.println();
                    menuOpcionesCatalogo(controlador);
                    break;
                case "2": //Editar un producto.
                    editarUnProducto(controlador);
                    break;
                case "3": //Ver resumen de todos los clientes.
                    System.out.println(controlador.pintaClientes());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "4": //Ver resumen de todos los pedidos.
                    System.out.println(controlador.pintaPedidos());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "5": //Ver resumen de todos los trabajadores.
                    System.out.println(controlador.pintaTrabajadores());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "6": //Ver estadísticas de la APP.
                    Menus.menuEstadisticasAPP(controlador);
                    Utils.pulsaParaContinuar();
                    break;
                case "7": //Modificar el estado de un pedido.
                    modificaEstadoPedidosParaAdmin(controlador);
                    break;
                case "8": //Dar de alta a un trabajador.
                    boolean esTrabajador = true;
                    pintaFormularioRegistro(controlador,esTrabajador);
                    break;
                case "9": //Dar de baja a un trabajador.
                    darDeBajaTrabajador(controlador);
                    break;
                case "10": //Asignar un pedido a un trabajador.
                    asignaPedidoTrabajador(controlador);
                    break;
                case "11": //Asignar IdTelegram a Trabajador.
                    asignaIdTelegramTrabajador(controlador);
                    break;
                case "12": //Mostrar configuración del programa.
                    leeFicheroConfiguracion(controlador);
                    break;
                case "13": //Enviar listado de pedidos por correo en formato Excel.
                    exportarPedidosExcel(controlador);
                    break;
                case "14": //Realizar copia de seguridad.
                    realizarCopiaSeguridad(controlador);
                    break;
                case "15": //Cerrar Sesión
                    System.out.println("¡Hasta la próxima crack! Vuelve pronto a gestionar la mejor APP :D");
                    Utils.cerrandoSesion();
                    //Escribo el cierre de sesión en el archivo log:
                    controlador.escribeCierreSesionLog(((Admin) user).getNombre(), "Administrador");
                    Utils.limpiaPantalla();
                    break;
                default:
                    System.out.println("    · Opción Incorrecta, vuelva a probar.");
            }
        } while (!op.equalsIgnoreCase("15"));
    }

    private static void exportarPedidosExcel(Controlador controlador) {
        System.out.print("Introduce el correo al que quiere mandar el excel con los pedidos: ");
        String email = S.nextLine();
        if (Utils.validarEmail(email)) {
            //creo el archivo excel con los pedidos:
            controlador.escribeArchivoExcel();
            //envío correo con el archivo excel:
            //<a src="otherFiles/excel/pedidos.csv">HAZ CLICK PARA DESCARGAR EL EXCEL</a>
            Comunicaciones.enviarCSV(email,controlador.getRutaExcel());

            Utils.pulsaParaContinuar();
        } else {
            System.out.println("Formato de email incorrecto.");
            Utils.pulsaParaContinuar();
        }
    }

    //Función que realiza la copia de seguridad:
    private static void realizarCopiaSeguridad(Controlador controlador) {
        File dir = new File(iniciaProperties().getProperty("RUTA_BACKUP"));
        System.out.println("Introduzca la ruta en la que quiere hacer la copia de seguridad.");
        System.out.println("EJEMPLO 1: C:\\Users\\user\\Desktop\\backupEscritorio (Ruta Absoluta - necesita crear una carpeta padre)");
        System.out.printf("EJEMPLO 2: %s (Si quiere usar esta ruta introduce \"S\"): ", "PracticaObligatoriaTema6_MZ\\backup");
        String ruta = S.nextLine();
        try {
            Controlador controladorBackup = new Controlador();
            if (ruta.equalsIgnoreCase("s")){

                if (controlador.realizarCopiaSeguridad(dir, controladorBackup)) System.out.println("Se ha podido realizar la copia de seguridad con éxito.");
                else System.out.println("Ha habido un error al hacer la copia.");
            } else {
                File r = new File(ruta);
                try {
                    if (controlador.realizarCopiaSeguridad(r, controladorBackup)) System.out.println("Se ha podido realizar la copia de seguridad con éxito.");
                    else System.out.println("Ha habido un error al hacer la copia.");
                } catch (Exception e) {
                    System.out.println("    · La ruta de la carpeta no es válida. Pruebe con otra.");
                }
            }
        } catch (Exception e){
            System.out.println("    · La ruta de la carpeta no es válida. Pruebe con otra.");
        }
        Utils.pulsaParaContinuar();
    }

    //Función que lee el fichero config y lo muestra por pantalla:
    private static void leeFicheroConfiguracion(Controlador controlador) {
        System.out.println("**************************************");
        System.out.println(controlador.leeFicheroConfiguracion());
        System.out.println("**************************************");
        Utils.pulsaParaContinuar();
    }

    //función que da de baja a un trabajador:
    private static void darDeBajaTrabajador(Controlador controlador) {
        System.out.println(controlador.pintaTrabajadores());
        System.out.print(" · Inserta el ID del trabajador que quieres dar de baja: ");
        String idTrabajador = S.nextLine();
        Trabajador t = controlador.getTrabajadorPorID(idTrabajador);
        Trabajador t2 = new Trabajador(t);
        if (controlador.eliminaTrabajadorPorId(idTrabajador)){
            System.out.println("El trabajador con ID: "+idTrabajador+" ha sido eliminado.");
            //ELIMINAMOS EL ARCHIVO DEL TRABAJADOR:
            controlador.getDaOtrabajadorSQL().borraTrabajador(t,controlador.getDao(),controlador.getDaOtrabajadorSQL());
        } else System.out.println("El trabajador no se ha podido eliminar. Inténtelo de nuevo con otra ID.");
        Utils.pulsaParaContinuar();
        //Mandamos email de despedida al trabajador:
        Comunicaciones.enviarMensaje(t2.getEmail(),
                "Ha sido dad@ de Baja | FernanShopMZ",
                Email.mensajeDespedidaTrabajador(t2.getNombre()));
        //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
        if (!t2.getIdTelegram().equalsIgnoreCase("")){
            Comunicaciones.enviaMensajeTelegram(Comunicaciones.mensajeTrabajadorDadoBaja(t2.getId()),
                    t2.getIdTelegram());
        }
    }

    //función que permite al administrador asignar pedidos sin asignar a los trabajadores:
    private static void asignaPedidoTrabajador(Controlador controlador) {
        System.out.println(controlador.pintaPedidos(controlador.getPedidosSinAsignar()));
        System.out.print("Introduce la ID de un pedido para asignar: ");
        String idPedido = S.nextLine();
        if (controlador.exitePedidoPendientePorId(idPedido)){
            System.out.println(controlador.pintaTrabajadores());
            System.out.print("Introduzca la ID del Trabajador al que quiere asignarle el pedido: ");
            String idTrabaj = S.nextLine();
            if (controlador.asignaPedidoTrabajador(idPedido,idTrabaj)) {
                Utils.loading();
                System.out.print("Pedido Asignado con Éxito\n");
                Utils.pulsaParaContinuar();
                Trabajador t = controlador.buscaTrabajadorPorIdPedido(idPedido);
                //NOTIFICAMOS AL TRABAJADOR POR EMAIL:
                Comunicaciones.enviarMensaje(t.getEmail(),
                            "Nuevo Pedido Asignado | FernanShopMZ",
                        Email.mensajeNuevoPedidoTrabajador(t,controlador.buscaPedidoByID(idPedido),
                                controlador.getClientePorIdPedido(idPedido)));
                //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
                if (t.getIdTelegram() != null && !t.getIdTelegram().equalsIgnoreCase("")){
                    Comunicaciones.enviaMensajeTelegram(Comunicaciones.mensajeNuevoPedidoTrabajador(idPedido,
                            controlador.devuelveStringEstado(controlador.buscaPedidoByID(idPedido).getEstado())),
                            t.getIdTelegram());
                }
                //GUARDAMOS EL PEDIDO CON EL TRABAJADOR EN BBDD:
                controlador.getDaOpedidoSQL().insertarPedidoTrabajador(t,controlador.buscaPedidoByID(idPedido),controlador.getDao());

            } else {
                System.out.println("No se ha podido asignar ese pedido al trabajador.");
                Utils.pulsaParaContinuar();
            }
        } else{
            System.out.println("  · La ID introducida no existe. Pruebe otra vez.");
            Utils.pulsaParaContinuar();
        }
    }

    //función que permite cambiar el estado de los pedidos al administrador (puede ver todos los pedidos):
    private static void modificaEstadoPedidosParaAdmin(Controlador controlador) {
        controlador.pintaPedidos();
        System.out.print("Introduce la ID del pedido al que desea modificarle el estado: ");
        String id = S.nextLine();
        if (controlador.exitePedidoPendientePorId(id)){
            Menus.submenuCambiaEstadoConsola();
            try {
                System.out.print("Introduce el estado al que quiere cambiarlo: ");
                int estado = Integer.parseInt(S.nextLine());
                Pedido p = controlador.buscaPedidoByID(id);
                //Recuperamos el trabajador para hacer operaciones:
                Trabajador t = controlador.buscaTrabajadorPorIdPedido(p.getId());
                //Le cambiamos el estado al pedido:
                controlador.cambiaEstadoPedido(p,estado);
                if (t != null && t.buscaPedidoByID(p.getId()) != null) t.buscaPedidoByID(p.getId()).setEstado(estado);
                //Le preguntamos al trabajador si quiere añadir un comentario:
                System.out.print("¿Quieres añadir un comentario al pedido? (S/N): ");
                String comentario = S.nextLine();
                if (comentario.equalsIgnoreCase("s")){
                    System.out.print("Introduce el comentario que quiere poner: ");
                    comentario = S.nextLine();
                    p.setComentario(comentario);
                    Utils.datoModificado();
                }
                if (t != null) t.buscaPedidoByID(p.getId()).setComentario(comentario);
                //NOTIFICAMOS AL CLIENTE POR CORREO:
                Comunicaciones.enviarMensaje(controlador.getClientePorIdPedido(p.getId()).getEmail(),
                        "Nuevo Cambio de Estado en su Pedido | FernanShopMZ",
                        Email.mensajeCambiaEstadoPedido(controlador.getClientePorIdPedido(p.getId())
                                ,p));
                if (t != null){
                    //NOTIFICAMOS AL TRABAJADOR POR CORREO:
                    Comunicaciones.enviarMensaje(t.getEmail(),
                            "Nuevo Cambio de Estado en un Pedido | FernanShopMZ",
                            Email.mensajeNuevoPedidoTrabajador(t,
                                    p,controlador.getClientePorIdPedido(p.getId())));
                    //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
                    if (t != null && !t.getIdTelegram().equalsIgnoreCase("")){
                        Comunicaciones.enviaMensajeTelegram(Comunicaciones.mensajeInformaEstadoPedido(id,
                                controlador.devuelveStringEstado(p.getEstado())),t.getIdTelegram());
                    }
                }

                //GUARDAMOS EL PEDIDO EN BBDD:
                controlador.getDaOpedidoSQL().modificarPedido(p,controlador.getDao());

                //Escribo la actualización del pedido en el log:
                controlador.escribeActualizacionPedidoLog(p.getId(),
                        Utils.devuelveStringEstado(p.getEstado()));
            } catch (Exception e){
                System.out.print("  · Error: Dato introducido incorrecto.\n");
                System.out.println(e.getMessage());
            }
        } else System.out.println("  · La ID introducida no existe. Pruebe otra vez.\n");
        Utils.pulsaParaContinuar();
    }

    //Función para asignar una Id de Telegram a un Trabajador en el menú Admin:
            // (ESTA OPCIÓN ES EXTRA, LA HEMOS AÑADIDO NOSOTRAS)
    private static void asignaIdTelegramTrabajador(Controlador controlador) {
        String idTelegram = "";
        do {
            System.out.print(" · Introduzca el id de Telegram (Inserta NO para salir): ");
            idTelegram = S.nextLine();
            if (!idTelegram.equalsIgnoreCase("no")){
                System.out.println(controlador.pintaTrabajadores());
                System.out.print(" · Introduce la ID del trabajador para asignarle la ID de Telegram: ");
                String idTrab = S.nextLine();
                if (controlador.asignaIdTelegram(idTelegram,idTrab)){
                    System.out.println("Se ha asignado la ID correctamente.");
                    //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
                    Trabajador t = controlador.getTrabajadorPorID(idTrab);
                    if (!t.getIdTelegram().equalsIgnoreCase("")){
                        Comunicaciones.enviaMensajeTelegram(Comunicaciones.mensajeTrabajadorDadoAlta(t.getId()),
                                t.getIdTelegram());
                    }
                    //GUARDAMOS TRABAJADOR EN BBDD:
                    controlador.getDaOtrabajadorSQL().modificarTrabajador(t,controlador.getDao());
                } else System.out.println("Ha habido un problema, no se ha podido asignar la ID. Inténtelo de nuevo.");
            }
        } while (idTelegram.length() != 10);
        Utils.pulsaParaContinuar();
        Utils.limpiaPantalla();
    }

    //Función para editar un producto en el menu Administrador:
    private static void editarUnProducto(Controlador controlador) {
        int op1 = 0;
        do {
            try {
                Menus.menuCambiaDatosProducto();
                op1 = Integer.parseInt(S.nextLine());
                if (op1 > 0 && op1 < 5) {
                    System.out.print("Introduce la ID del producto que deseas modificar: ");
                    int idProducto = Integer.parseInt(S.nextLine());
                    if (controlador.buscaProductoById(idProducto)!=null){
                        System.out.print("Introduce el dato por el que quiere cambiarlo: ");
                        String dato = S.nextLine();
                        if (controlador.cambiaDatoProductoCatalogo(op1,idProducto,dato)){
                            //GUARDAMOS EL PRODUCTO EN BBDD:
                            controlador.getDaOproductoSQL().modificarProducto(
                                    controlador.buscaProductoByID(idProducto),
                                    controlador.getDao());
                            Utils.datoModificado();
                        }else Utils.mensajeDatoIncorrecto();
                    }
                } else if (op1 != 5) System.out.println(" · Opción incorrecta.");
            } catch (Exception e){
                System.out.print(" · Error: formato introducido incorrecto.");
            }
            Utils.limpiaPantalla();
        } while (op1 != 5);
    }

                                                                                    //FUNCIONES TRABAJADORES
    //Menú Trabajador:
    private static void menuTrabajador(Controlador controlador, Object user) {
        //Copio la información del objeto user a un nuevo objeto de tipo Trabajador y los casteo:
        Trabajador trabajador = (Trabajador) user;
        String op = "";
        do {
            System.out.println();
            //Escribo el inicio de sesión en el archivo log:
            controlador.escribeInicioSesionLog(((Trabajador) user).getNombre(), "Trabajador");
            //Doy la bienvenida al usuario:
            System.out.println("¡Bienvenido/a, " + trabajador.getNombre() + "! Tienes " +
                    trabajador.numPedidosPendientes() + " pedidos que gestionar.");

            //Enseño por pantalla la linea del último inicio de sesión (si el usuario tiene):
            if (!controlador.getUltimoInicioSesion(((Trabajador) user).getId()).equalsIgnoreCase("")) {
                System.out.println("Usted inició sesión por última vez el " + controlador.getUltimoInicioSesion(((Trabajador) user).getId()) + ".");
            }
            //Llamamos al properties para grabar su inicio de sesión:
            controlador.grabaInicioSesion(((Trabajador) user).getId());

            Menus.menuTrabajadorConsola();
            System.out.println();
            System.out.print("Introduce una opción: ");
            op = S.nextLine();
            System.out.println();
            switch (op) {
                case "1": //Consultar los pedidos asignados.
                    System.out.println(trabajador.pintaPedidosAsignados(controlador));
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "2": //Modificar el estado de un pedido.
                    if (trabajador.numPedidosPendientes() != 0) modificaEstadoPedido(controlador, trabajador);
                    else{
                        System.out.println("  · No tienes pedidos para modificar.");
                        Utils.pulsaParaContinuar();
                        Utils.limpiaPantalla();
                    }
                    break;
                case "3": //Consultar el catálogo de productos.
                    menuOpcionesCatalogo(controlador);
                    break;
                case "4": //Modificar un producto del catálogo.
                    modificaProductoCatalogo(controlador);
                    break;
                case "5": //Ver el histórico de pedidos terminados.
                    System.out.println(trabajador.getPedidosTerminados(controlador));
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "6": //Ver mi perfil.
                    System.out.println(trabajador.pintaDatosTrabajador());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;
                case "7": //Modificar mis datos personales.
                    String op1 = "";
                    do {
                        Menus.menuCambiarDatosTrabajador();
                        System.out.print("Introduzca la opción que desea modificar: ");
                        op1 = S.nextLine();
                        cambiaDatosTrabajador(op1,trabajador, controlador);
                        //GUARDAMOS EL TRABAJADOR EN BBDD:
                        controlador.getDaOtrabajadorSQL().modificarTrabajador(trabajador,controlador.getDao());
                        //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
                        if (trabajador.getIdTelegram()!=null && !trabajador.getIdTelegram().equalsIgnoreCase("")){
                            Comunicaciones.enviaMensajeTelegram(Comunicaciones.mensajeDatosModificados(),
                                    trabajador.getIdTelegram());
                        }
                    } while (!op1.equalsIgnoreCase("6"));
                    break;
                case "8": //Cerrar Sesión
                    System.out.println("¡Hasta la próxima querido trabajador! Vuelva Pronto :)");
                    Utils.cerrandoSesion();
                    //Escribo el cierre de sesión en el archivo log:
                    controlador.escribeCierreSesionLog(((Trabajador) user).getNombre(), "Trabajador");
                    Utils.limpiaPantalla();
                    break;
                default:
                    System.out.println("    · Opción Incorrecta, vuelva a probar.");
                }
        } while (!op.equalsIgnoreCase("8"));
    }

    //Función que modifica el estado de un pedido:
    private static void modificaEstadoPedido(Controlador controlador, Trabajador trabajador) {
        ArrayList<Pedido> pedidos = new ArrayList<>(trabajador.getPedidosAsignados());
        System.out.println(trabajador.pintaPedidosAsignados(controlador));
        try {
            System.out.print("Introduce el pedido al que quiere modificarle el estado: ");
            int num = Integer.parseInt(S.nextLine());
            //Creo un cliente temporal para guardarlo posteriormente:
            Cliente temp = controlador.getClientePorIdPedido(pedidos.get(num - 1).getId());
            if (num < 1 || num > trabajador.getPedidosAsignados().size()){
                System.out.print("    · Error, pedido no válido.");
            } else {
                Menus.submenuCambiaEstadoConsola();
                System.out.print("Introduce el estado al que quiere modificarlo: ");
                int opEstado = Integer.parseInt(S.nextLine());
                if (controlador.cambiaEstadoPedido(trabajador.getPedidosAsignados().get(num - 1),opEstado)){
                    Utils.datoModificado();
                    //Le preguntamos al trabajador si quiere añadir un omentario:
                    System.out.print("¿Quieres añadir un comentario al pedido? (S/N): ");
                    String comentario = S.nextLine();
                    if (comentario.equalsIgnoreCase("s")){
                        System.out.print("Introduce el comentario que quiere poner: ");
                        comentario = S.nextLine();
                        controlador.buscaPedidoByID(pedidos.get(num - 1).getId()).setComentario(comentario);
                        trabajador.buscaPedidoByID(pedidos.get(num - 1).getId()).setComentario(comentario);
                        Utils.datoModificado();
                    }
                    //Manda un email al cliente para informarle de que su pedido ha cambiado de estado:
                    Comunicaciones.enviarMensaje(controlador.getClientePorIdPedido(pedidos.get(num - 1).getId()).getEmail(),
                            "Nuevo Cambio de Estado en su Pedido | FernanShopMZ",
                            Email.mensajeCambiaEstadoPedido(controlador.getClientePorIdPedido(pedidos.get(num - 1).getId())
                                    ,pedidos.get(num - 1)));
                }
                else Utils.mensajeOpcionIncorrecta();
            }
            //MODIFICAMOS EL PEDIDO EN BBDD:
            controlador.getDaOpedidoSQL().modificarPedido(controlador.buscaPedidoByID(pedidos.get(num - 1).getId()),
                    controlador.getDao());

            //Escribo la actualización del pedido en el log:
            controlador.escribeActualizacionPedidoLog(pedidos.get(num - 1).getId(),
                    Utils.devuelveStringEstado(pedidos.get(num - 1).getEstado()));
        } catch (Exception e) {
            Utils.mensajeDatoIncorrecto();
        }
        Utils.pulsaParaContinuar();
    }

    //Función que pinta un menú para cambiar datos de un producto del catálogo:
    private static void modificaProductoCatalogo(Controlador controlador) {
        boolean datoValido = true;
        String idProducto = "";
        do {
            System.out.print("Introduzca el ID del producto que desea modificar (-1 para salir): ");
            idProducto = S.nextLine();
            for (int i = 0; i < idProducto.length(); i++) {
                if (Character.isLetter(idProducto.charAt(i))){
                    System.out.println("  · Id introducido incorrecto. ");
                    datoValido = false;
                    break;
                }
            }
            if (datoValido){
                System.out.println();
                Menus.menuCambiaDatosProducto();
                if (cambiaDatosProducto(controlador,idProducto)){
                    try {
                        //GUARDAMOS PRODUCTO EN BBDD:
                        controlador.getDaOproductoSQL().modificarProducto(
                                controlador.buscaProductoByID(Integer.parseInt(idProducto)),
                                controlador.getDao());
                    } catch (NumberFormatException e){
                        Utils.mensajeDatoIncorrecto();
                    }
                    Utils.datoModificado();
                }
                else System.out.println("   · El producto no se ha podido modificar.");
            }
        } while (!idProducto.equalsIgnoreCase("-1"));
    }

    //Método que modifica los datos de un producto del catálogo:
    private static boolean cambiaDatosProducto(Controlador controlador, String idProducto) {
        boolean datoValido = false;
        String op = "";
        System.out.print(" Introduce la opción que quiere modificar: ");
        op = S.nextLine();
        switch(op){
            case "1": //Marca
                String marcaNueva = "";
                do {
                    System.out.print("  · Introduce la nueva marca (N: para salir): ");
                    marcaNueva = S.nextLine();
                    if (marcaNueva.equalsIgnoreCase("n")){
                        return false;
                    } else{
                        if (controlador.validaStringIntroducido(marcaNueva)){
                            datoValido = true;
                            controlador.buscaProductoByID(Integer.parseInt(idProducto)).setMarca(marcaNueva);
                        }
                    }
                } while (!datoValido);
                return true;
            case "2": //Modelo
                String modeloNuevo = "";
                do {
                    System.out.print("  · Introduce el nuevo modelo (N: para salir): ");
                    modeloNuevo = S.nextLine();
                    if (modeloNuevo.equalsIgnoreCase("n")){
                        return false;
                    } else{
                        if (controlador.validaStringIntroducido(modeloNuevo)){
                            datoValido = true;
                            controlador.buscaProductoByID(Integer.parseInt(idProducto)).setModelo(modeloNuevo);
                        }
                    }
                } while (!datoValido);
                return true;
            case "3": //Descripción
                String descripcionNueva = "";
                do {
                    System.out.print("  · Introduce la nueva descripción (N: para salir): ");
                    descripcionNueva = S.nextLine();
                    if (descripcionNueva.equalsIgnoreCase("n")){
                        return false;
                    } else{
                        if (controlador.validaStringIntroducido(descripcionNueva)){
                            datoValido = true;
                            controlador.buscaProductoByID(Integer.parseInt(idProducto)).setDescripcion(descripcionNueva);
                        }
                    }
                } while (!datoValido);
                return true;
            case "4": //Precio
                String precioNuevo = "";
                do {
                    System.out.print("  · Introduce el nuevo precio (N: para salir): ");
                    precioNuevo = S.nextLine();
                    if (precioNuevo.equalsIgnoreCase("n")){
                        return false;
                    } else{
                        if (controlador.validaPrecio(precioNuevo)){
                            datoValido = true;
                            controlador.buscaProductoByID(Integer.parseInt(idProducto)).setPrecio(Float.parseFloat(precioNuevo));
                        }
                    }
                } while (!datoValido);
                return true;
            case "5": //Salir
                Utils.saliendo();
                Utils.limpiaPantalla();
                break;
            default: Utils.mensajeOpcionIncorrecta();
        }
        return false;
    }

                                                                                    //FUNCIONES CLIENTES Y DEMÁS
    //Menú Cliente:
    private static void menuCliente(Controlador controlador, Object user) {
        //Copio la información del objeto user a un nuevo objeto de tipo Cliente y los casteo:
        Cliente cliente = (Cliente) user;
        String op = "";
        do {
            System.out.println();
            //Escribo el inicio de sesión en el archivo log:
            controlador.escribeInicioSesionLog(((Cliente) user).getNombre(), "Cliente");
            //Doy la bienvenida al usuario:
            System.out.println("¡Bienvenido/a, " + cliente.getNombre() + "! Tiene " + cliente.cuentaPedidosSinEntregar()
                    + " " + ((cliente.cuentaPedidosSinEntregar() == 1)? "pedido pendiente" : "pedidos pendientes") + " de entrega.");

            //Enseño por pantalla la linea del último inicio de sesión (si el usuario tiene):
            if (!controlador.getUltimoInicioSesion(((Cliente) user).getId()).equalsIgnoreCase("")) {
                System.out.println("Usted inició sesión por última vez el " + controlador.getUltimoInicioSesion(((Cliente) user).getId()) + ".");
            }
            //Llamamos al properties para grabar su inicio de sesión:
            controlador.grabaInicioSesion(((Cliente) user).getId());

            Menus.menuClienteConsola(cliente.getNombre(),cliente.cuentaPedidosSinEntregar());
            System.out.print("Introduce una opción: ");
            op = S.nextLine();
            switch (op){
                case "1": //Consultar catálogo de productos.
                    menuOpcionesCatalogo(controlador);
                    break;

                case "2": //Realizar un pedido.
                    String op1 = "";
                    do {
                        System.out.println();
                        Menus.submenuRealizarPedidoConsola(cliente.numProductosCarro());
                        System.out.print("Introduzca la opción deseada: ");
                        op1 = S.nextLine();
                        System.out.println();
                        menuOpcionesPedido(op1, controlador, cliente);
                    } while (!op1.equalsIgnoreCase("6"));
                    break;

                case "3": //Ver mis pedidos.
                    System.out.print(cliente.pintaPedidosCliente(controlador));
                    Utils.pulsaParaContinuar();
                    break;

                case "4": //Ver mis datos personales.
                    System.out.println(cliente.pintaDatosCliente());
                    Utils.pulsaParaContinuar();
                    break;

                case "5": //Modificar mis datos personales.
                    String op2 = "";
                    do {
                        Menus.menuCambiarDatosCliente();
                        System.out.print("Introduzca la opción que desea modificar: ");
                        op2 = S.nextLine();
                        cambiaDatosCliente(op2,cliente, controlador);
                        //Guardo el nuevo cambio en BBDD:
                        controlador.getDaOclienteSQL().modificarCliente(cliente,controlador.getDao());
                    } while (!op2.equalsIgnoreCase("8"));
                    break;

                case "6": //Cerrar Sesión
                    System.out.println("¡Hasta la próxima! Vuelva Pronto :)");
                    Utils.cerrandoSesion();
                    //Escribo el cierre de sesión en el archivo log:
                    controlador.escribeCierreSesionLog(((Cliente) user).getNombre(), "Cliente");
                    Utils.limpiaPantalla();
                    break;

                default:
                    System.out.println("    · Opción Incorrecta, vuelva a probar.");
            }
            Utils.limpiaPantalla();
        } while (!op.equalsIgnoreCase("6"));

    }

    //Función que pinta el menú de opciones de Realizar un Pedido del Cliente:
    private static void menuOpcionesPedido(String op, Controlador controlador, Cliente cliente) {
        switch (op){
            case "1": //Inserta un producto en el carro.
                int idProducto = 0;
                do {
                    menuOpcionesCatalogo(controlador);
                    try {
                        System.out.print("Introduzca el ID del producto que desea añadir al carro (Pulse -1 para salir): ");
                        idProducto = Integer.parseInt(S.nextLine());
                    } catch (Exception e) {
                        Utils.mensajeOpcionIncorrecta();
                        break;
                    }
                    if (idProducto != -1){
                        Producto producto = controlador.buscaProductoById(idProducto);
                        if (producto==null)
                            System.out.println("Producto no encontrado.");
                        else {
                            if (controlador.addProductoCarrito(cliente,idProducto)){
                                System.out.println("Producto añadido al carrito con éxito.");
                                //Guardamos el producto en BBDD (Carrito-Producto):
                                controlador.getDaOproductoSQL().insertarProductoCarrito(cliente,producto,controlador.getDao());
                            }else System.out.println("Error: No se ha podido añadir el producto.");
                        }
                        Utils.pulsaParaContinuar();
                    }
                    Utils.limpiaPantalla();
                } while (idProducto != -1);
                break;
            case "2": //Ver el carro.
                System.out.println(cliente.pintaCarro());
                Utils.pulsaParaContinuar();
                break;
            case "3": //Eliminar un producto del carro.
                do {
                    System.out.println(cliente.pintaCarro());
                    try {
                        System.out.print("Introduce el ID del producto que desea eliminar del carrito (Pulse -1 para salir): ");
                        idProducto = Integer.parseInt(S.nextLine());
                    } catch (Exception e) {
                        Utils.mensajeOpcionIncorrecta();
                        break;
                    }
                    if (idProducto != -1){
                        Producto producto = controlador.buscaProductoByIdCarro(cliente,idProducto);
                        if (producto==null)
                            System.out.println("Producto no encontrado.");
                        else {
                            if (controlador.removeProductoCarrito(cliente,idProducto,controlador)){
                                System.out.println("Producto eliminado del carrito con éxito.");
                            }else System.out.println("Error: No se ha podido eliminar el producto.");
                        }
                        Utils.pulsaParaContinuar();
                    }
                } while (idProducto != -1);

                Utils.pulsaParaContinuar();
                break;
            case "4": //Confirmar el pedido.
                System.out.print("Pulsa para confirmar definitivamente el pedido con los productos del carrito: ");
                S.nextLine();
                Pedido temp = new Pedido(controlador.confirmaPedidoCliente(cliente, controlador));
                cliente.getPedidos().add(temp); //añado el pedido hecho por el carro a la lista de pedidos
                if (temp != null && !temp.getProductos().isEmpty()){
                    System.out.println("    · Pedido confirmado con éxito :)");
                    //GUARDAMOS EL PEDIDO EN BBDD (Tablas: Pedido, Pedido_Producto):
                    controlador.getDaOpedidoSQL().insertarPedido(cliente,temp,controlador.getDao());
                    controlador.getDaOpedidoSQL().insertarPedidoProducto(cliente,temp,controlador.getDao());

                    //Guardo el PDF en disco:
                    generaPdf(temp,controlador);
                    //Le mandamos al cliente un email para confirmar que su pedido ha sido creado con éxito:
                    Comunicaciones.enviaPdf(cliente.getEmail(),"Confirmación de Pedido | FernanShopMZ",
                            Email.mensajeConfirmaPedido(cliente, temp),
                            controlador.getRutaPdf() + temp.getId() + ".pdf");

                    //Intentamos asignar el pedido al trabajador con menos pedidos:
                    if (controlador.buscaTrabajadorCandidatoParaAsignar() != null){
                        Trabajador t = controlador.buscaTrabajadorCandidatoParaAsignar();
                        controlador.asignaPedidoTrabajador(temp);
                        Comunicaciones.enviarMensaje(t.getEmail(),
                                "Nuevo Pedido Asignado | FernanShopMZ",
                                Email.mensajeNuevoPedidoTrabajador(t,temp,
                                        controlador.getClientePorIdPedido(temp.getId())));
                        //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:
                        if (t.getIdTelegram() != null && !t.getIdTelegram().equalsIgnoreCase("")){
                            Comunicaciones.enviaMensajeTelegram(Comunicaciones.
                                    mensajeNuevoPedidoTrabajador(temp.getId(),
                                            controlador.devuelveStringEstado(temp.getEstado())),
                                    t.getIdTelegram());
                        }
                        //GUARDAMOS EL PEDIDO CON EL TRABAJADOR EN BBDD:
                        controlador.getDaOpedidoSQL().insertarPedidoTrabajador(t,temp,controlador.getDao());
                        //Escribo la creación del nuevo pedido en el archivo log:
                        controlador.escribeNuevoPedidoLog(cliente.getId(), t.getId());


                    } else {
                        //Escribo la creación del nuevo pedido en el archivo log pasándole "-" porque no se le
                        // ha podido asignar el pedido a ningún trabajador:
                        controlador.escribeNuevoPedidoLog(cliente.getId(), "-");
                    };
                    //Borro el carrito en BBDD:
                    controlador.getDaOproductoSQL().borraProductosCarrito(cliente,controlador.getDao(),controlador.getDaOproductoSQL());

                }
                else System.out.println("    · Error: No se ha podido confirmar el pedido.");
                Utils.limpiaPantalla();
                break;
            case "5": //Cancelar el pedido.
                int numPedido = 0;
                do {
                    System.out.print(cliente.pintaPedidosCliente(controlador));
                    System.out.println();
                    try{
                        System.out.print("Introduce el número del pedido que quiere cancelar (-1 para salir): ");
                        numPedido = Integer.parseInt(S.nextLine());
                        if (numPedido != -1){
                            if (numPedido >= 0 && !controlador.buscaPedidoByNum(cliente,numPedido))
                                System.out.print("No existe el pedido introducido.\n");
                            else {
                                if (cliente.getPedidos().get(numPedido - 1).getEstado() != 3 &&
                                        cliente.getPedidos().get(numPedido - 1).getEstado() != 4){

                                    //Seteo el estado
                                    cliente.getPedidos().get(numPedido - 1).setEstado(3);

                                    //Modifico el estado del pedido en BBDD:
                                    controlador.getDaOpedidoSQL().modificarPedido(
                                            cliente.getPedidos().get(numPedido - 1),
                                            controlador.getDao());

                                    System.out.print("Se ha cancelado el pedido con éxito.\n");
                                    System.out.println();

                                    //Manda un email al cliente para informarle de que su pedido ha cambiado de estado:
                                    Comunicaciones.enviarMensaje(cliente.getEmail(),
                                            "Nuevo Cambio de Estado en su Pedido | FernanShopMZ",
                                            Email.mensajeCambiaEstadoPedido(cliente
                                                    ,cliente.getPedidos().get(numPedido - 1)));

                                    //Mandamos el email al trabajador que lo tenía asignado:
                                    if (controlador.getPedidosAsignados().contains(cliente.getPedidos().get(numPedido - 1))){
                                        Trabajador t = controlador.buscaTrabajadorPorIdPedido(cliente.getPedidos().
                                                get(numPedido - 1).getId());
                                        Comunicaciones.enviarMensaje(t.getEmail(),
                                                "Nuevo Cambio de Estado en un Pedido | FernanShopMZ",
                                                Email.mensajeNuevoPedidoTrabajador(t,
                                                        cliente.getPedidos().get(numPedido - 1),cliente));

                                        //NOTIFICAMOS AL TRABAJADOR POR TELEGRAM:

                                        if (t.getIdTelegram() != null &&
                                                !t.getIdTelegram().equalsIgnoreCase("")){
                                            Comunicaciones.enviaMensajeTelegram(
                                                    Comunicaciones.mensajeInformaEstadoPedido(
                                                            cliente.getPedidos().get(numPedido - 1).getId(),
                                                            controlador.devuelveStringEstado(
                                                                cliente.getPedidos().get(numPedido - 1).getEstado())),
                                                    t.getIdTelegram());
                                        }

                                        //Escribo la actualización del pedido en el log:
                                        controlador.escribeActualizacionPedidoLog(
                                                cliente.getPedidos().get(numPedido - 1).getId(),
                                                Utils.devuelveStringEstado(
                                                        cliente.getPedidos().get(numPedido - 1).getEstado()));
                                    } else System.out.println("   · Pedido pendiente de asignación.\n");
                                    System.out.println();
                                } else{
                                    System.out.print("Este pedido no se puede cancelar.\n");
                                    Utils.pulsaParaContinuar();
                                    System.out.println();
                                }
                            }
                        }
                    } catch (Exception e){
                        System.out.print("  · Formato introducido incorrecto.\n\n");
                    }
                } while (numPedido != -1 && numPedido < cliente.getPedidos().size() +1);
                Utils.saliendo();
                Utils.limpiaPantalla();
                break;
            case "6": //SALIR
                Utils.saliendo();
                Utils.limpiaPantalla();
                break;
            default: Utils.mensajeOpcionIncorrecta();
        }
    }

    //Función que pinta un menú para cambiar datos del Cliente:
    private static void cambiaDatosCliente(String op1, Cliente cliente, Controlador controlador) {
        switch (op1){
            case "1": //EMAIL
                String op = "";
                String email = "";
                boolean registrado = false;
                do {
                    //Pido el email y lo valido:
                    email = pideEmail(controlador);
                    if (controlador.buscaEmailRegistrado(email)) {
                        System.out.print("    · Ese email está ya registrado. ¿Quiere probar de nuevo? (S/N): ");
                        op = S.nextLine();
                    } else {
                        //Pido el Código de Verificación del email:
                        pideCodVerificacionEmail(controlador, email, cliente.getNombre());
                        cliente.setEmail(email);
                        Utils.pulsaParaContinuar();
                        registrado = true;
                    }
                } while (!registrado && !op.equalsIgnoreCase("n"));
                System.out.println();
                break;
            case "2": //CLAVE
                //Pido la contraseña y la valido:
                System.out.print("Introduzca su actual contraseña para continuar: ");
                if (S.nextLine().equalsIgnoreCase(cliente.getClave())){
                    String claveNueva = pideClave();
                    cliente.setClave(claveNueva);
                    Utils.datoModificado();
                } else System.out.println("     · La contraseña no coincide. Pruebe de nuevo.");
                break;
            case "3": //NOMBRE
                System.out.print("Introduzca el nuevo nombre de Usuario: ");
                cliente.setNombre(S.nextLine());
                Utils.datoModificado();
                break;
            case "4": //DIRECCIÓN
                System.out.print("Introduzca la nueva dirección: ");
                cliente.setDireccion(S.nextLine());
                Utils.datoModificado();
                break;
            case "5": //LOCALIDAD
                System.out.print("Introduzca la nueva localidad: ");
                cliente.setLocalidad(S.nextLine());
                Utils.datoModificado();
                break;
            case "6": //PROVINCIA
                System.out.print("Introduzca la nueva provincia: ");
                cliente.setProvincia(S.nextLine());
                Utils.datoModificado();
                break;
            case "7": //TELÉFONO
                int telefono = pideTelefono();
                cliente.setMovil(telefono);
                Utils.datoModificado();
                break;
            case "8": //SALIR
                Utils.saliendo();
                Utils.limpiaPantalla();
                break;
            default: Utils.mensajeOpcionIncorrecta();
        }
    }

    //Función que pinta un menú para cambiar datos del trabajador:
    private static void cambiaDatosTrabajador(String op1, Trabajador trabajador, Controlador controlador) {
        switch (op1){
            case "1": //EMAIL
                String op = "";
                String email = "";
                do {
                    email = pideEmail(controlador);
                    if (controlador.buscaEmailRegistrado(email)) {
                        System.out.print("    · Ese email está ya registrado. ¿Quiere probar de nuevo? (S/N): ");
                        op = S.nextLine();
                        if (op.equalsIgnoreCase("n")){
                            Utils.loading();
                            Utils.limpiaPantalla();
                        }
                    } else {
                        op = "n";
                        Utils.loading();
                        Utils.datoModificado();
                    }
                } while (!op.equalsIgnoreCase("n"));
                //Cuando se da de alta a un trabajador no hace falta validar el correo con un código.
                break;
            case "2": //CLAVE
                //Pido la contraseña y la valido:
                System.out.print("Introduzca su actual contraseña para continuar: ");
                if (S.nextLine().equalsIgnoreCase(trabajador.getClave())){
                    String claveNueva = pideClave();
                    trabajador.setClave(claveNueva);
                    Utils.datoModificado();
                } else System.out.println("     · La contraseña no coincide. Pruebe de nuevo.");
                break;
            case "3": //NOMBRE
                String nombreMod = "";
                System.out.print("Introduzca el nuevo nombre de Usuario: ");
                nombreMod = S.nextLine();
                if (!nombreMod.isEmpty()){
                    trabajador.setNombre(nombreMod);
                    Utils.datoModificado();
                } else System.out.println("     · El nombre no puede estar vacío.\n");
                break;
            case "4": //TELÉFONO
                int telefono = pideTelefono();
                trabajador.setMovil(telefono);
                Utils.datoModificado();
                break;
            case "5": //ID TELEGRAM
                String idTelegram = "";
                System.out.print("Introduzca la nuevo ID de Telegram: ");
                idTelegram = S.nextLine();
                if (idTelegram.length() == 10){
                    trabajador.setIdTelegram(idTelegram);
                    Utils.datoModificado();
                } else System.out.println("     · La ID de Telegram no es válida.\n");
                break;
            case "6": //SALIR
                Utils.saliendo();
                Utils.limpiaPantalla();
                break;
            default: Utils.mensajeOpcionIncorrecta();
        }
    }


    //Función que se encarga de pintar el menú del catálogo de productos (Búsquedas de productos)
    private static void menuOpcionesCatalogo(Controlador controlador) {
        String op = "";
        do {
            if (controlador.esInvitado()) Menus.menuConsultaProductosInvitado();
            else Menus.submenuConsultaProductosConsola();
            System.out.print("Introduce la opción deseada: ");
            op = S.nextLine();
            System.out.println();
            switch (op){
                case "1": //VER CATÁLOGO ENTERO
                    pintaCatalogo(controlador, controlador.getCatalogo());
                    break;
                case "2": //BUSCAR POR MARCA
                    String marca = "";
                    System.out.print("Introduzca la Marca que quiere buscar: ");
                    marca = S.nextLine();
                    Utils.loading();
                    pintaCatalogo(controlador, controlador.buscaProductosByMarca(marca));
                    break;
                case "3": //BUSCAR POR MODELO
                    String modelo = "";
                    System.out.print("Introduzca el Modelo que quiere buscar: ");
                    modelo = S.nextLine();
                    Utils.loading();
                    pintaCatalogo(controlador, controlador.buscaProductosByModelo(modelo));
                    break;
                case "4": //BUSCAR POR DESCRIPCIÓN
                    String descripcion = "";
                    System.out.print("Introduzca la Descripción que quiere buscar: ");
                    descripcion = S.nextLine();
                    Utils.loading();
                    pintaCatalogo(controlador, controlador.buscaProductosByDescripcion(descripcion));
                    break;
                case "5": //BUSCAR POR TÉRMINO
                    String termino = "";
                    System.out.print("Introduzca el Término que quiere buscar: ");
                    termino = S.nextLine();
                    Utils.loading();
                    pintaCatalogo(controlador, controlador.buscaProductosByTermino(termino));
                    break;
                case "6": //BUSCAR POR PRECIO
                    float precioMin = 0, precioMax = 0;
                    boolean correcto;
                    do {
                        try {
                            correcto = true;
                            System.out.print("Introduzca el Precio Mínimo: ");
                            precioMin = Float.parseFloat(S.nextLine());
                            System.out.print("Introduzca el Precio Máximo: ");
                            precioMax = Float.parseFloat(S.nextLine());
                        } catch (Exception E){
                            correcto = false;
                            System.out.println("    · Error: Introduzca un valor correcto. ");
                            Utils.pulsaParaContinuar();
                        }
                    } while (!correcto);
                    Utils.loading();
                    pintaCatalogo(controlador, controlador.buscaProductosByPrecio(precioMin, precioMax));
                    break;
                case "7": //SALIR
                    if (controlador.esInvitado()) System.out.println("    · Opción Incorrecta, pruebe otra vez.\n");
                    else Utils.saliendo();
                    break;
                default:
                    System.out.println("    · Opción Incorrecta, pruebe otra vez.\n");
            }
        } while (!op.equalsIgnoreCase("7"));
    }

    //Menú Inicial:
    private static Object menuInicio(Controlador controlador) {
        if (controlador.esInvitado()) {
            do {
                menuOpcionesCatalogo(controlador);
            } while (true);
        } else {
            Menus.menuPrincipalConsola();
            int op = introduceOpcionMenuPrincipal();
            return opcionesMenuPrincipal(op, controlador);
        }
    }

    //Función para llamar a introducir una opción:
    private static int introduceOpcionMenuPrincipal() {
        int op = -1;
        do {
            try {
                System.out.print("Introduzca la opción deseada: ");
                op = Integer.parseInt(S.nextLine());
                if (op < 0 || op > 2) Utils.mensajeOpcionIncorrecta();
            } catch (Exception e) {
                Utils.mensajeOpcionIncorrecta();
            }
        } while (op < 0 || op > 2);
        return op;
    }

    //Función para realizar las distintas opciones del menú principal:
    private static Object opcionesMenuPrincipal(int op, Controlador controlador) {
        //creamos un user temporal para guardar el objeto usuario del logueo y el registro.
        Object user = null;

        //Hacemos un switch de las opciones de nuestro software:
        switch (op) {
            case 0: //Ver Catálogo
                System.out.println();
                menuOpcionesCatalogo(controlador);
                Utils.limpiaPantalla();
                break;
            case 1: //Iniciar Sesión
                String op1 = "";
                do {
                    System.out.print("Introduce tu email: ");
                    String email = S.nextLine();
                    System.out.print("Introduce tu contraseña: ");
                    String clave = S.nextLine();
                    //Creo un método para saber si el email y la contraseña existen.
                    // Devuelve null si no encuentra ningún usuario con esos datos.
                    user = controlador.devuelveUsuario(email,clave);
                    if (user == null){
                        System.out.print("   · Email o clave incorrectos. ¿Quiere volver a probar? (S/N): ");
                        op1 = S.nextLine();
                    } else{
                        Utils.loading();
                        return user;
                    }
                } while (!op1.equalsIgnoreCase("n"));
                System.out.println();
                break;
            case 2: //Registrarse
                boolean esTrabajador = false;
                Cliente clienteTemp = (Cliente) pintaFormularioRegistro(controlador,esTrabajador);
                if (clienteTemp != null) user = new Cliente(clienteTemp);
                break;
            default:
                System.out.println("    · Opción introducida incorrecta, pruebe de nuevo.");
        }
        return user;
    }

    //Función que pinta un formulario de Registro:
    private static Object pintaFormularioRegistro(Controlador controlador, boolean esTrabajador) {
        String op = "";
        String email;
        String localidad = "";
        String provincia = "";
        String direccion = "";
        boolean emailValido = false;

        System.out.println("""
                                    
                                    ╔═══════════════════════════════════╗
                                    ║       FORMULARIO DE REGISTRO      ║
                                    ╚═══════════════════════════════════╝
                                    """);
        do {
            //Pido el email y lo valido:
            email = pideEmail(controlador);
            if (!email.equalsIgnoreCase("volver al menu")){
                if (controlador.buscaEmailRegistrado(email)) {
                    System.out.print("    · Ese email está ya registrado. ¿Quiere probar de nuevo? (S/N): ");
                    op = S.nextLine();
                    if (op.equalsIgnoreCase("n")) Utils.loading();
                } else emailValido = true;
            } else Utils.limpiaPantalla();
        } while (!op.equalsIgnoreCase("n") && !emailValido && !email.equalsIgnoreCase("volver al menu"));

        if (emailValido){
            //Pido la contraseña y la valido:
            String clave = pideClave();

            //Pido el nombre:
            System.out.print("·Introduzca su nombre: ");
            String nombre = Utils.quitarAcentos(S.nextLine());

            if (!esTrabajador){
                //Pido la localidad:
                System.out.print("·Introduzca su localidad: ");
                localidad = Utils.quitarAcentos(S.nextLine());

                //Pido la provincia:
                System.out.print("·Introduzca su provincia: ");
                provincia = Utils.quitarAcentos(S.nextLine());

                //Pido la dirección:
                System.out.print("·Introduzca su dirección: ");
                direccion = Utils.quitarAcentos(S.nextLine());
            }

            //Pido el teléfono:
            int telefono = pideTelefono();

            if (!esTrabajador){
                //Pido el Código de Verificación del email:
                pideCodVerificacionEmail(controlador, email, nombre);
                //Creamos el cliente con la información del formulario:
                Cliente cliente = new Cliente(email,clave,nombre,localidad,provincia,direccion,telefono,controlador);
                //Metemos el cliente ya creado en el array del controlador:
                controlador.getClientes().add(cliente);
                //GUARDAMOS EL CLIENTE EN BBDD:
                controlador.getDaOclienteSQL().insertarCliente(cliente,controlador.getDao());
                Utils.pulsaParaContinuar();
                Utils.limpiaPantalla();
                return cliente;
            } else {
                //Cuando se da de alta a un trabajador no hace falta validar el correo con un código.
                //Creamos el trabajador con la información del formulario:
                Trabajador trabajador = new Trabajador(nombre,clave,email,telefono,controlador);
                Comunicaciones.enviarMensaje(trabajador.getEmail(),
                        "¡Bienvenido a FernanShop! | FernanShopMZ",
                        Email.mensajeBienvenidaTrabajador(trabajador.getNombre()));
                //Metemos el trabajador ya creado en el array del controlador:
                controlador.insertaTrabajador(trabajador);
                //GUARDAMOS EL TRABAJADOR EN BBDD:
                controlador.getDaOtrabajadorSQL().insertarTrabajador(trabajador,controlador.getDao());

                System.out.println("Trabajador dado de Alta con Éxito.");
                System.out.println(" · Escriba al bot '@fernanShopMZ_bot' de Telegram para poder recibir avisos por Telegram ·\n");
                Utils.pulsaParaContinuar();
                Utils.limpiaPantalla();
                return trabajador;
            }
        }
        return null;
    }

    //Función que pide el número de teléfono y valida el formato:
    private static int pideTelefono() {
        boolean datoValido = false;
        int telefono = 0;
        do {
            try {
                System.out.print("·Introduzca su nuevo teléfono móvil: ");
                telefono = Integer.parseInt(S.nextLine());
            } catch (Exception e){
                System.out.println("    · El formato del nº de teléfono es incorrecto, pruebe de nuevo.");
                datoValido = false;
            }
            datoValido = true;
            if (datoValido && (telefono<100000000 || telefono>999999999))
                System.out.println("    · El nº de teléfono debe tener 9 cifras, pruebe de nuevo.");
        }while (!datoValido || (telefono<100000000 || telefono>999999999));
        return telefono;
    }

    //Función que pide la clave al registrarse:
    private static String pideClave() {
        String clave;
        String claveConf = "-1";
        do {
            System.out.print("·Introduzca su nueva contraseña: ");
            clave = S.nextLine();
            if (!clave.isEmpty()){
                System.out.print("·Introduzca de nuevo su contraseña para confirmar: ");
                claveConf = S.nextLine();
                if (!clave.equalsIgnoreCase(claveConf)) System.out.println("   · Por favor, introduzca la misma clave");
                else System.out.println("   · Clave Confirmada");
            } else System.out.print("   · La clave no puede estar vacía.\n");
        } while (!clave.equalsIgnoreCase(claveConf));
        return clave;
    }

    //Función que pide el código de verificación al registrarse:
    private static void pideCodVerificacionEmail(Controlador controlador, String email, String nombre) {
        //Pido el código de verificación:
        //Primero manda directamente un codigo de validacion al cliente:

        String codVerificacion = "";
        String numeroValidacionAleatorio = generaNumeroValidacion();
        Comunicaciones.enviarMensaje(email,
                "Código de Verificación | FernanShopMZ",
                Email.mensajeRegistroCliente(nombre, numeroValidacionAleatorio));
        do {
            for (int i = 0; i <= 3; i++) {
                System.out.print("·Introduzca el código que le hemos mandado a su correo electrónico: ");
                codVerificacion = S.nextLine();
                if (codVerificacion.equalsIgnoreCase(numeroValidacionAleatorio)){
                    System.out.println("    · Código Correcto :)");
                    break;
                } else System.out.println("    · Código Incorrecto :(");

                if (i==3){
                    System.out.println("¿Quieres recibir nuevamente el código de verificación? (S/N): ");
                    String op = S.nextLine();
                    if (op.equalsIgnoreCase("n")) break;
                    else{
                        numeroValidacionAleatorio = generaNumeroValidacion();
                        Comunicaciones.enviarMensaje(email,
                                "Código de Verificación | FernanShopMZ",
                                Email.mensajeRegistroCliente(nombre, numeroValidacionAleatorio));
                    }
                }
            }   //TODO: QUITAR LA PARTE DE SEGUIR CON EL -1, ESO SOLO ES PARA PROBAR
        } while (!codVerificacion.equalsIgnoreCase(numeroValidacionAleatorio));
    }

    //Función que pide el email al registrarse:
    private static String pideEmail(Controlador controlador) {
        boolean datoValido = true;
        String email;
        //Pido email:
        do {
            System.out.print("·Introduzca el email: ");
            email = S.nextLine();
            if (!Utils.validarEmail(email)){
                System.out.println("    · El formato del email es incorrecto.");
                System.out.print("¿Quiere volver al menú principal? (S/N): ");
                String op = S.nextLine();
                if (op.equalsIgnoreCase("S")) return email = "volver al menu";
                else datoValido = false;
            } else datoValido = true;
        } while (!datoValido);
        return email;
    }

    //Función que pinta el catálogo de productos:
    private static void pintaCatalogo(Controlador controlador, ArrayList<Producto> productos) {
        //variable para continuar viendo el catalogo
        String opCatalogo = "";

        //Bucle para pintar los productos
        if (productos.isEmpty()){
            System.out.println("   · Lo sentimos, no existen productos con la búsqueda establecida...");
            Utils.pulsaParaContinuar();
        }else{
            do {
                for (int i = 1; i <= productos.size(); i++) {
                    pintaProducto(productos.get(i-1));
                    System.out.println();
                    Utils.esperaProducto();
                    //Si ha sacado 5 productos le preguntamos si quiere seguir viendo:
                    if (i % 5 == 0) {
                        System.out.print("\t¿Quiere seguir viendo nuevos productos? (S/N): ");
                        opCatalogo = S.nextLine();
                        if (!opCatalogo.equalsIgnoreCase("n")) System.out.println();
                    }
                    if (i == productos.size()) {
                        System.out.print("\tNo hay más productos. ¿Quieres empezar a verlos de nuevo? (S/N): ");
                        opCatalogo = S.nextLine();
                        if (!opCatalogo.equalsIgnoreCase("n")) System.out.println();
                    }
                    if (opCatalogo.equalsIgnoreCase("N")) break;
                }
            } while (!opCatalogo.equalsIgnoreCase("N"));
        }
        System.out.println();
    }

    //Función para pintar un producto individual:
    private static void pintaProducto(Producto producto) {
        //Creo variables String con los marcos base
        String borde = "╔══════════════════════════════════════════════════════════════════════════════╗";
        String separador = "╠══════════════════════════════════════════════════════════════════════════════╣";
        String cierre = "╚══════════════════════════════════════════════════════════════════════════════╝";
        //Si cumple con la relevancia cambiamos los marcos
        if (producto.getRelevancia() > 9) {
            borde = "╔═****************************************************************************═╗";
            separador = "╠═****************************************************************************═╣";
            cierre = "╚═****************************************************************************═╝";
        }
        //Empezamos a formar el cuadro con los datos del producto
        String modeloCentrado = String.format("║ %-76s ║", String.format("%76s", producto.getModelo().toUpperCase()));
        String contenido = String.format(
                "║ %-76s ║\n" +
                        "║ %-76s ║\n" +
                        "║ %-76s ║\n" +
                        "║ %-76s ║",
                String.format("· Id Producto: %d", producto.getId()),
                String.format("· Marca: %s", producto.getMarca()),
                String.format("· Descripción: %s", producto.getDescripcion()),
                String.format("· Precio: %.2f E", producto.getPrecio())
        );
        //Unimos las diferentes lineas del cuadro en un último printf
        System.out.printf("""
                        %s
                        %s
                        %s
                        %s
                        %s
                        """,
                borde,
                modeloCentrado,
                separador,
                contenido,
                cierre
        );
    }


}