package persistencia;

import controlador.Controlador;
import models.*;
import utils.Utils;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Properties;


public class Persistencia {
    public static final String RUTA_CONFIG = "properties/config.properties";

    //método que carga el properties:
    public static Properties iniciaProperties(){
        Properties prop = new Properties();
        FileReader fr;
        try {
            fr = new FileReader(RUTA_CONFIG);
            prop.load(fr);
            fr.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return prop;
    }

    //MÉTODOS PARA GUARDAR LOS DATOS DEL CONTROLADOR EN DISCO AL PRINCIPIO DEL PROGRAMA:
    public static void guardaProductos(Controlador controlador, File directorio) {
        for (Producto pr : controlador.getCatalogo()){
            guardaProducto(pr,directorio);
        }
    }

    public static void guardaClientes(Controlador controlador, File directorio) {
        for (Cliente c : controlador.getClientes()){
            guardaCliente(c, directorio);
        }
    }

    public static void guardaTrabajadores(Controlador controlador, File directorio) {
        for (Trabajador t : controlador.getTrabajadores()){
            guardaTrabajador(t, directorio);
        }
    }

    public static void guardaAdministradores(Controlador controlador, File directorio) {
        for (Admin a : controlador.getAdmins()){
            guardaAdministrador(a, directorio);
        }
    }


    //MÉTODOS PARA GUARDAR OBJETOS INDIVIDUALES EN DISCO:
    public static void guardaProducto(Producto pr, File directorio) {
        //Controlar si la carpeta no existe que la cree automáticamente.
        try {
            File temp = new File(directorio + iniciaProperties().getProperty("RUTA_PROD"));
            if (!temp.exists()) temp.mkdir();
            FileOutputStream fos = new FileOutputStream(directorio + iniciaProperties().getProperty("RUTA_PROD")
                    + "\\" + pr.getId() + ".prod");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(pr);
            oos.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void guardaCliente(Cliente c, File directorio) {
        try {
            File temp = new File(directorio + iniciaProperties().getProperty("RUTA_CLIE"));
            if (!temp.exists()) temp.mkdir();
            FileOutputStream fos = new FileOutputStream( directorio + iniciaProperties().getProperty("RUTA_CLIE")
                    + "\\" + c.getId() + ".clie");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(c);
            oos.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void guardaTrabajador(Trabajador t, File directorio) {
        try {
            File temp = new File(directorio + iniciaProperties().getProperty("RUTA_TRAB"));
            if (!temp.exists()) temp.mkdir();
            FileOutputStream fos = new FileOutputStream(directorio + iniciaProperties().getProperty("RUTA_TRAB")
                    + "\\" + t.getId() + ".trab");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(t);
            oos.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void guardaAdministrador(Admin a, File directorio) {
        try {
            File temp = new File(directorio + iniciaProperties().getProperty("RUTA_ADMIN"));
            if (!temp.exists()) temp.mkdir();
            FileOutputStream fos = new FileOutputStream(directorio + iniciaProperties().getProperty("RUTA_ADMIN")
                    + "\\" + a.getId() + ".admin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(a);
            oos.close();
            fos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    //MÉTODO PARA ELIMINAR EL ARCHIVO DEL TRABAJADOR:
    public static void eliminaDataTrabajador(Trabajador t) {
        File f = new File(iniciaProperties().getProperty("RUTA_TRAB") + "\\" + t.getId() + ".trab");
        f.delete();
    }

    public static String leeFicheroConfiguracion() {
        String resultado = "";
        try {
            FileReader fr = new FileReader(RUTA_CONFIG);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            do {
                resultado += linea + "\n";
                linea = br.readLine();
            } while (linea != null);
            br.close();
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return resultado;
    }

    public static boolean realizarCopiaSeguridad(File dir, Controlador controlador) {
        //Se copian los objetos del controlador en carpetas:
        controlador.guardaDatos(dir);
        return true;
    }

    //método que obtiene el último inicio de sesión de una id:
    public static String getUltimoInicioSesion(String id) {
        try {
            FileReader fr = new FileReader(RUTA_CONFIG);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            do {
                if (linea.contains(id)){
                    String fecha = linea.substring(linea.indexOf("=")+1);
                    fecha = Utils.formateaFechaString(fecha);
                    return fecha;
                }
                linea = br.readLine();
            } while (linea != null);
            br.close();
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return "";
    }

    //método que graba un inicio de sesión en el properties:
    public static void grabaInicioSesion(String id) {
        String config = "";
        try {
            //Voy leyendo cada una de las lineas, si contiene el id buscado la ignoro:
            FileReader fr = new FileReader(RUTA_CONFIG);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            do {
                if (!linea.contains(id)) config += linea + "\n";
                linea = br.readLine();
            } while (linea != null);
            br.close();
            fr.close();

            //Grabo el último inicio de sesión:
            File directorio = new File(RUTA_CONFIG);
            //Borro el archivo para que no se concatene lo que había antes:
            directorio.delete();
            FileWriter fw = new FileWriter(directorio);
            BufferedWriter bw = new BufferedWriter(fw);
            //Añado al config todo lo que había antes:
            bw.write(config);
            //Añado la línea del nuevo inicio de sesión:
            bw.write(id + "=" + LocalDate.now());
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //método para devolver true o false si la APP está o no en modo invitado:
    public static boolean esInvitado() {
        Properties prop = new Properties(iniciaProperties());
        String esInvitado = prop.getProperty("MODO_INVITADO");
        if (esInvitado.equalsIgnoreCase("true")) return true;
        return false;
    }

    //método para escribir en el archivo log todos los inicios de sesión de la APP:
    public static void escribeInicioSesionLog(String nombre, String tipoUser) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_LOG"));
            FileWriter fw = new FileWriter(directorio,true);
            BufferedWriter bw = new BufferedWriter(fw);
            //Añado la línea del nuevo inicio de sesión:
            bw.write("Inicio de Sesión;" + nombre + ";" + tipoUser + ";" +
                    Utils.formateaFechaString(String.valueOf(LocalDate.now())) + "/" + LocalDateTime.now().getHour() +
                    ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + "\n");
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void escribeCierreSesionLog(String nombre, String tipoUser) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_LOG"));
            FileWriter fw = new FileWriter(directorio,true);
            BufferedWriter bw = new BufferedWriter(fw);
            //Añado la línea del nuevo inicio de sesión:
            bw.write("Cierre de Sesión;" + nombre + ";" + tipoUser + ";" +
                    Utils.formateaFechaString(String.valueOf(LocalDate.now())) + "/" + LocalDateTime.now().getHour() +
                    ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + "\n");
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void escribeNuevoPedidoLog(String idClie, String idTrab) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_LOG"));
            FileWriter fw = new FileWriter(directorio,true);
            BufferedWriter bw = new BufferedWriter(fw);
            //Añado la línea del nuevo inicio de sesión:
            bw.write("Nuevo Pedido;" + idClie + ";" + idTrab + ";" +
                    Utils.formateaFechaString(String.valueOf(LocalDate.now())) + "/" + LocalDateTime.now().getHour() +
                    ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + "\n");
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void escribeActualizacionPedidoLog(String idPedido, String estadoPedido) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_LOG"));
            FileWriter fw = new FileWriter(directorio,true);
            BufferedWriter bw = new BufferedWriter(fw);
            //Añado la línea del nuevo inicio de sesión:
            bw.write("Actualización Pedido;" + idPedido + ";" + estadoPedido + ";" +
                    Utils.formateaFechaString(String.valueOf(LocalDate.now())) + "/" + LocalDateTime.now().getHour() +
                    ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + "\n");
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void escribeArchivoExcel(ArrayList<Pedido> pedidosTotales) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_EXCEL"));
            FileWriter fw = new FileWriter(directorio);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("ID_PEDIDO;FECHA_PEDIDO;ESTADO;COMENTARIO;ID_PRODUCTOS\n");
            for (Pedido p : pedidosTotales){
                bw.write(p.getId() + ";" + Utils.formatearFecha(p.getFechaPedido()) + ";" +
                        Utils.devuelveStringEstado(p.getEstado()) + ";" +
                        ((p.getComentario().isEmpty())? "-":p.getComentario()));
                for (Producto pr : p.getProductos()){
                    bw.write(";" + pr.getId());
                }
                bw.write("\n");
            }
            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void escribeArchivoPdf(Pedido pedido) {
        String config = "";
        try {
            File directorio = new File(iniciaProperties().getProperty("RUTA_PDF"));
            FileWriter fw = new FileWriter(directorio);
            BufferedWriter bw = new BufferedWriter(fw);


            bw.close();
            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

